import logging
import requests
import json
import os

from ibm_watsonx_orchestrate.agent_builder.tools import ToolPermission, tool
from ibm_watsonx_orchestrate.run import connections
from ibm_watsonx_orchestrate.client.connections import ConnectionType
from ibm_watsonx_orchestrate.run.context import AgentRun
# from utils.matchedcompany import MatchedCompany
from utils.payload_validator import (
    sanitize_portfolio_payload,
    validate_required_fields,
)
from utils.data_services_client import DataServicesClient

# Set up logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

CONNECTION_DNB = "dnb_key_value_dnb_4c6e8dad"
is_called_from_orchestrate = True


def _serialize_model_instance(model):
    """Convert pydantic/BaseModel objects into plain dictionaries."""
    if model is None:
        return None

    for attr in ("model_dump", "dict"):
        serializer = getattr(model, attr, None)
        if callable(serializer):
            try:
                return serializer()
            except TypeError:
                continue

    return getattr(model, "__dict__", model)


@tool(
    name="dnb_supplier_discovery_v5",
    permission=ToolPermission.READ_WRITE,
    expected_credentials=[
        {"app_id": CONNECTION_DNB, "type": ConnectionType.KEY_VALUE},
    ],
)
def dnb_supplier_discovery(search_payload: str, context: AgentRun) -> dict:
    """
    Search for suppliers using search criteria

    Args:
        search_payload: String with key=value pairs separated by commas
        context: context of Agent run

    Returns:
        Dictionary with sanitized_payload, candidates list, and error message if any
    """

    search_results = {
        "sanitized_payload": None,
        "candidates": [],
        "error": None
    }

    try:
        # Handle multiple input formats
        if isinstance(search_payload, str):
            logger.info(f"Received search_payload as string, parsing...")
            
            # Try JSON format first
            try:
                search_criteria = json.loads(search_payload)
                logger.info("Parsed as JSON successfully")
            except json.JSONDecodeError:
                # Try key=value format: "naics=812320, countryISOAlpha2Code=US, pageSize=5"
                logger.info("JSON parse failed, trying key=value format...")
                search_criteria = {}
                
                try:
                    # Split by comma, then by equals
                    for pair in search_payload.split(','):
                        if '=' not in pair:
                            continue
                        key, value = pair.split('=', 1)
                        key = key.strip()
                        value = value.strip()
                        
                        # Type conversion
                        if value.lower() == 'true':
                            search_criteria[key] = True
                        elif value.lower() == 'false':
                            search_criteria[key] = False
                        elif value.isdigit():
                            search_criteria[key] = int(value)
                        elif value.replace('.', '', 1).isdigit():
                            search_criteria[key] = float(value)
                        else:
                            search_criteria[key] = value
                    
                    logger.info("Parsed as key=value format successfully")
                except Exception as e:
                    error_message = f"Failed to parse payload: {str(e)}"
                    logger.error(error_message)
                    return {
                        "sanitized_payload": None,
                        "candidates": [],
                        "error": error_message
                    }
        elif isinstance(search_payload, dict):
            logger.info(f"Received search_payload as dict")
            search_criteria = search_payload
        else:
            error_message = f"Invalid payload type: {type(search_payload)}"
            logger.error(error_message)
            return {
                "sanitized_payload": None,
                "candidates": [],
                "error": error_message
            }
        
        logger.info(f"Search criteria keys: {list(search_criteria.keys())}")
        
        # API URL
        api_url = "https://application-26.1zy11kva25nl.us-south.codeengine.appdomain.cloud"
        
        # The supplier discovery API endpoint
        url = f"{api_url}/api/v1/dnb/search/suppliers"
        
        # Build headers
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        
        # Obtain data service API token using DNB client credentials
        try:
            token = None
            if is_called_from_orchestrate:
                dnb_creds = connections.key_value(CONNECTION_DNB)
                client_id = dnb_creds.get("client_id", "")
                client_secret = dnb_creds.get("client_secret", "")
            else:
                # Local testing: read from environment variables
                client_id = os.getenv("DNB_CLIENT_ID", "")
                client_secret = os.getenv("DNB_CLIENT_SECRET", "")
            
            if client_id and client_secret:
                logger.info("Requesting data service API token via client_credentials grant using DNB credentials")
                token_url = f"{api_url}/api/v1/auth/authenticate"
                client = DataServicesClient(
                    base_url=api_url,
                    token_url=token_url,
                    client_id=client_id,
                    client_secret=client_secret
                )
                client.authenticate_sync()
                token = client.bearer_token
            else:
                logger.error("Missing client_id/client_secret - cannot obtain token")
                return {
                    "sanitized_payload": search_criteria,
                    "candidates": [],
                    "error": "Missing client_id/client_secret - cannot obtain token"
                    }
            
            if token:
                headers["Authorization"] = f"Bearer {token}"
                logger.info("Added Authorization bearer token to headers")
            else:
                logger.error("Failed to fetch Bearer token")
                return {
                    "sanitized_payload": search_criteria,
                    "candidates": [],
                    "error": "Failed to fetch Bearer token"
                    }
        except Exception as e:
            logger.error(f"Error obtaining data service API token: {e}")
            return {
                "sanitized_payload": search_criteria,
                "candidates": [],
                "error": f"Error obtaining data service API token: {e}"
            }
        
        # get user id from request context and set in headers
        user_id = "DUMMY_USER_ID"
        if is_called_from_orchestrate and context:
            req_context = context.request_context
            user_id = req_context.get('user_id')
            if not user_id:
                logger.warning("No user ID found in request context, using DUMMY_USER_ID")
                user_id = "DUMMY_USER_ID"
        
        headers["X-User-Id"] = user_id

        search_results = _dnb_supplier_discovery(url, headers, search_criteria)
    except Exception as e:
        error_message = f"Unexpected error: {str(e)}"
        search_results['error'] = error_message
        logger.error(repr(e))

    return search_results

def _dnb_supplier_discovery(url, headers, search_criteria)  -> dict:

    matched_candidates = []
    sanitized_payload = None
    error_message = None

    try:
        # Sanitize and validate payload
        sanitized_payload = sanitize_portfolio_payload(search_criteria)
        validate_required_fields(sanitized_payload)
        payload = sanitized_payload
        
        # agreed with D&B that search will return active business unless otherwise specified
        if "isOutOfBusiness" not in payload:
            payload["isOutOfBusiness"] = [False]
        
        # logger.info(f"Sanitized payload keys: {list(payload.keys())}")
        logger.info(f"Sanitized payload: {payload}")

        # Call the supplier discovery API (payload already sanitized)
        logger.info(f"Calling supplier discovery API: POST {url}")
        logger.info(f"Headers keys: {list(headers.keys())}")
        
        response = requests.post(
            url=url,
            headers=headers,
            data=json.dumps(payload),
            timeout=30,
        )
        
        logger.info(f"Response status: {response.status_code}")
        if response.status_code != 200:
            logger.error(f"Supplier discovery API returned status {response.status_code}: {response.text}")
            error_message = f"API error: {response.status_code}"
            # extract and return the API errorMessage
            try:
                error_response = response.json()
                if isinstance(error_response, dict) and "error" in error_response:
                    extracted_message = error_response["error"].get("errorMessage")
                    if extracted_message:
                        error_message = extracted_message
                        logger.info(f"Extracted error message: {error_message}")
            except (json.JSONDecodeError, AttributeError, KeyError) as e:
                logger.warning(f"Could not parse error response: {e}")
            
            return {
                "sanitized_payload": sanitized_payload,
                "candidates": [],
                "error": error_message
            }
        
        response_data = response.json()
        logger.info(f"Response type: {type(response_data)}")
        
        if isinstance(response_data, list):
            companies = response_data
            logger.info(f"Got direct array with {len(companies)} items")
        elif isinstance(response_data, dict):
            # Check for error first
            if "error" in response_data:
                error_message = response_data["error"].get("errorMessage", "Unknown error")
                logger.error(error_message)
                return {
                    "sanitized_payload": sanitized_payload,
                    "candidates": [],
                    "error": error_message
                }
            
            companies = (
                response_data.get("suppliers") or 
                response_data.get("results") or 
                response_data.get("data") or 
                response_data.get("companies") or 
                response_data.get("organizations") or
                []
            )
            logger.info(f"Got wrapped response with {len(companies)} items")
        else:
            logger.error(f"Unexpected response type: {type(response_data)}")
            return {
                "sanitized_payload": sanitized_payload,
                "candidates": [],
                "error": "Unexpected response format"
            }
        
        if not companies:
            logger.info("No companies found")
            return {
                "sanitized_payload": sanitized_payload,
                "candidates": [],
                "error": None
            }
        
        logger.info(f"Processing {len(companies)} companies")

        header = "| Name | D-U-N-S® | Location | Country | Status |"
        separator = "|---|---|---|---|---|"
        
        for candidate in companies:
            try:
                org = candidate.get("organization", candidate)
                primary_address = org.get("primaryAddress", {})
                duns = org["duns"]
                primary_name = org["primaryName"]
                locality_name = primary_address.get("addressLocality", {}).get("name", "")
                region_name = primary_address.get("addressRegion", {}).get("name", "")
                country_name = primary_address.get("addressCountry", {}).get("name", "")
                is_active = org.get("dunsControlStatus", {}).get("operatingStatus", {}).get("description", "")
                
                # matched_candidates.append(
                #     _serialize_model_instance(
                #         MatchedCompany(
                #         duns=org["duns"],
                #         primary_name=org["primaryName"],
                #         is_active=org.get("dunsControlStatus", {})
                #         .get("operatingStatus", {})
                #         .get("description", ""),
                #         country_code=primary_address.get("addressCountry", {}).get(
                #             "isoAlpha2Code", ""
                #         ),
                #         country_name=primary_address.get("addressCountry", {}).get(
                #             "name", ""
                #         ),
                #         locality_name=primary_address.get("addressLocality", {}).get(
                #             "name", ""
                #         ),
                #         region_name=primary_address.get("addressRegion", {}).get(
                #             "name", ""
                #         ),
                #         region_abbreviated_name=primary_address.get(
                #             "addressRegion", {}
                #         ).get("abbreviatedName", ""),
                #         postal_code=primary_address.get("postalCode", ""),
                #     )
                #     )
                # )
                matched_candidates.append(
                    f"| {primary_name} | {duns} | {locality_name}, {region_name} | {country_name} | {is_active} |"
                )
            except Exception as e:
                logger.warning(f"Failed to parse company record: {e}")
                continue
        logger.info(f"Found {len(matched_candidates)} companies")
        if len(matched_candidates) > 0:
            matched_candidates = [header, separator] + matched_candidates
            matched_candidates = "\n".join(matched_candidates)
            # matched_candidates = textwrap.dedent(matched_candidates)

    except ValueError as e:
        # Validation error (missing required fields, etc.)
        error_message = str(e)
        logger.error(f"Validation error: {error_message}")
    except requests.RequestException as e:
        error_message = f"Request error: {str(e)}"
        logger.error(f"Request error: {repr(e)}")
    except Exception as e:
        error_message = f"Unexpected error: {str(e)}"
        logger.error(f"Unexpected error: {repr(e)}")
    
    # logger.info(f"Found {len(matched_candidates)} companies")

    # serialised_candidates = []
    # for candidate in matched_candidates:
    #     try:
    #         serialised_candidates.append(candidate.dict())
    #     except Exception:
    #         serialised_candidates.append(candidate.__dict__)

    return {
        "sanitized_payload": sanitized_payload,
        "candidates": matched_candidates,
        "error": error_message
    }


if __name__ == "__main__":
    import os
    from dotenv import load_dotenv

    load_dotenv()
    is_called_from_orchestrate = False

    test_payload = "countryISOAlpha2Code=US, naics=424950, pageSize=10"
    # test_payload = "unspsc=50300000, countryISOAlpha2Code=US, paydexLowRangeScore=20, paydexHighRangeScore=70, pageSize=30"
    # test_payload = "addressLocality=Paris, countryISOAlpha2Code=FR, naics=511130, pageSize=10"
    # test_payload = "countryISOAlpha2Code=FR, naics=511130, pageSize=10"
    # test_payload = "countryISOAlpha2Code=US, naics=424950, pageSize=10"
    # test_payload = "unspsc=81112100, countryISOAlpha2Code=US, pageSize=30"
    # test_payload = "unspsc=43211503, countryISOAlpha2Code=US"


    result = dnb_supplier_discovery(test_payload, context=None)
    # print(f"Found {len(result['candidates'])} candidates:")
    if result["error"]:
        print(result)
    if result.get("user_id"):
        print(f"User ID: {result['user_id']}")
    # for candidate in result['candidates']:
    #     print(f"""  - {candidate.get("primary_name")} (DUNS: {candidate.get("duns")})""")
    print(result['candidates'])