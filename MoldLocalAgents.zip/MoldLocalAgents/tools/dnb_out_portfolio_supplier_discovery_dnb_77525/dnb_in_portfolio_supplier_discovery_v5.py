import logging
import requests
import json
import os

from ibm_watsonx_orchestrate.agent_builder.tools import ToolPermission, tool
from ibm_watsonx_orchestrate.run import connections
from ibm_watsonx_orchestrate.client.connections import ConnectionType
from ibm_watsonx_orchestrate.run.context import AgentRun
from utils.matchedcompany import MatchedCompany
from utils.payload_validator import sanitize_portfolio_payload
from utils.data_services_client import DataServicesClient

# Set up logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

is_called_from_orchestrate = True

def _serialize_model_instance(model):
    """Convert pydantic/BaseModel objects into plain dictionaries."""
    if model is None:
        return None

    for attr in ("model_dump", "dict"):
        serializer = getattr(model, attr, None)
        if callable(serializer):
            try:
                return serializer()
            except TypeError:
                continue

    return getattr(model, "__dict__", model)


@tool(
    name="dnb_in_portfolio_supplier_discovery_v5",
    permission=ToolPermission.READ_WRITE,
    expected_credentials=[
        {"app_id": "dnb_key_value_dnb_4c6e8dad", "type": ConnectionType.KEY_VALUE},
    ],
)
def dnb_in_portfolio_supplier_discovery(search_payload: str, context: AgentRun) -> dict:
    """
    Search for suppliers within your existing portfolio

    Args:
        search_payload: String with key=value pairs separated by commas
        context: context of Agent run

    Returns:
        Dictionary with sanitized_payload, candidates list, and error message if any
    """

    search_results = {
        "sanitized_payload": None,
        "candidates": [],
        "error": None
    }

    try:
        # Handle multiple input formats
        if isinstance(search_payload, str):
            logger.info(f"Received search_payload as string, parsing...")

            # Try JSON format first
            try:
                search_criteria = json.loads(search_payload)
                logger.info("Parsed as JSON successfully")
            except json.JSONDecodeError:
                # Try key=value format
                logger.info("JSON parse failed, trying key=value format...")
                search_criteria = {}

                try:
                    for pair in search_payload.split(','):
                        if '=' not in pair:
                            continue
                        key, value = pair.split('=', 1)
                        key = key.strip()
                        value = value.strip()

                        # Type conversion
                        if value.lower() == 'true':
                            search_criteria[key] = True
                        elif value.lower() == 'false':
                            search_criteria[key] = False
                        elif value.isdigit():
                            search_criteria[key] = int(value)
                        elif value.replace('.', '', 1).isdigit():
                            search_criteria[key] = float(value)
                        else:
                            search_criteria[key] = value

                    logger.info("Parsed as key=value format successfully")
                except Exception as e:
                    error_message = f"Failed to parse payload: {str(e)}"
                    logger.error(error_message)
                    return {
                        "sanitized_payload": None,
                        "candidates": [],
                        "error": error_message
                    }
        elif isinstance(search_payload, dict):
            logger.info(f"Received search_payload as dict")
            search_criteria = search_payload
        else:
            error_message = f"Invalid payload type: {type(search_payload)}"
            logger.error(error_message)
            return {
                "sanitized_payload": None,
                "candidates": [],
                "error": error_message
            }

        logger.info(f"IN Portfolio search_criteria keys: {list(search_criteria.keys())}")

        # Data Service API URL
        data_service_api_url = "https://application-26.1zy11kva25nl.us-south.codeengine.appdomain.cloud"

        # Build headers
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        # Obtain data service API token using DNB client credentials
        try:
            token = None
            if is_called_from_orchestrate:
                dnb_creds = connections.key_value("dnb_key_value_dnb_4c6e8dad")
                client_id = dnb_creds.get("client_id", "")
                client_secret = dnb_creds.get("client_secret", "")
            else:
                # Local testing: read from environment variables
                client_id = os.getenv("DNB_CLIENT_ID", "")
                client_secret = os.getenv("DNB_CLIENT_SECRET", "")

            if client_id and client_secret:
                logger.info("Requesting data service API token via client_credentials grant using DNB credentials")
                token_url = f"{data_service_api_url}/api/v1/auth/authenticate"
                client = DataServicesClient(
                    base_url=data_service_api_url,
                    token_url=token_url,
                    client_id=client_id,
                    client_secret=client_secret
                )
                client.authenticate_sync()
                token = client.bearer_token
            else:
                logger.error("Missing client_id/client_secret - cannot obtain token")
                return {
                    "sanitized_payload": search_criteria,
                    "candidates": [],
                    "error": "Missing client_id/client_secret - cannot obtain token"
                    }

            if token:
                headers["Authorization"] = f"Bearer {token}"
                logger.info("Added Authorization bearer token to headers")
            else:
                logger.error("Failed to fetch Bearer token")
                return {
                    "sanitized_payload": search_criteria,
                    "candidates": [],
                    "error": "Failed to fetch Bearer token"
                    }
        except Exception as e:
            logger.error(f"Error obtaining data service API token: {e}")
            return {
                "sanitized_payload": search_criteria,
                "candidates": [],
                "error": f"Error obtaining data service API token: {e}"
            }

        # get user id from request context and set in headers
        user_id = "DUMMY_USER_ID"
        if is_called_from_orchestrate and context:
            req_context = context.request_context
            user_id = req_context.get('user_id')
            if not user_id:
                logger.warning("No user ID found in request context, using DUMMY_USER_ID")
                user_id = "DUMMY_USER_ID"
        
        headers["X-User-Id"] = user_id

        # Decide endpoint based on inPortfolioCount flag
        in_portfolio_count = bool(search_criteria.pop("inPortfolioCount", False))
        if in_portfolio_count and len(search_criteria) == 0:
            # Count endpoint (expects GET with query params)
            url = f"{data_service_api_url}/api/v1/tenants/count"
            search_results = _dnb_in_portfolio_supplier_discovery(in_portfolio_count, url, headers, search_criteria)
        else:
            # The IN portfolio API endpoint (POST with JSON body)
            url = f"{data_service_api_url}/api/v2/portfolio/search/dataBlocks"

            search_results = _dnb_in_portfolio_supplier_discovery(in_portfolio_count, url, headers, search_criteria)
    except Exception as e:
        error_message = f"Unexpected error: {str(e)}"
        search_results['error'] = error_message
        logger.error(repr(e))

    return search_results

def _dnb_in_portfolio_supplier_discovery(in_portfolio_count, url, headers, search_criteria) -> dict:

    matched_candidates = []
    count_match_criteria = None
    sanitized_payload = None
    error_message = None

    try:
        # Call the API (payload already sanitized)
        if in_portfolio_count and len(search_criteria) == 0:
            logger.info(f"Calling data service API: GET {url}")
            logger.info(f"Headers keys: {list(headers.keys())}")
            response = requests.get(
                url=url,
                headers={k: v for k, v in headers.items() if k != "Content-Type"},
                # params=payload,
                timeout=30,
            )
        else:
            # Sanitize payload (no required fields validation for in-portfolio search)
            sanitized_payload = sanitize_portfolio_payload(search_criteria)
            payload = sanitized_payload

            # agreed with D&B that search will return active business unless otherwise specified
            if "isOutOfBusiness" not in payload:
                payload["isOutOfBusiness"] = [False]

            if "industryTerms" in payload:
                payload.pop("industryTerms")

            # logger.info(f"Sanitized payload keys: {list(payload.keys())}")
            logger.info(f"Sanitized payload: {payload}")
            logger.info(f"Calling data service API: POST {url}")
            logger.info(f"Headers keys: {list(headers.keys())}")
            response = requests.post(
                url=url,
                headers=headers,
                data=json.dumps(payload),
                timeout=30,
            )

        logger.info(f"Response status: {response.status_code}")
        if response.status_code != 200:
            logger.error(f"Data service API returned status {response.status_code}: {response.text}")
            error_message = f"API error: {response.status_code}"
            if in_portfolio_count and len(search_criteria) == 0:
                return {"count": 0, "error": error_message}
            return {
                "sanitized_payload": sanitized_payload,
                "candidates": [],
                "error": error_message
            }

        response_data = response.json()
        logger.info(f"Response type: {type(response_data)}")

        # If inPortfolioCount, return the count response directly
        if in_portfolio_count and len(search_criteria) == 0:
            try:
                count_value = int(response_data.get("count", 0)) if isinstance(response_data, dict) else 0
            except Exception:
                count_value = 0
            return {"count": count_value}

        if isinstance(response_data, list):
            companies = response_data
            logger.info(f"Got direct array with {len(companies)} items")
        elif isinstance(response_data, dict):
            # Check for error first
            if "error" in response_data:
                error_message = response_data["error"].get("errorMessage", "Unknown error")
                logger.error(error_message)
                return {
                    "sanitized_payload": sanitized_payload,
                    "candidates": [],
                    "error": error_message
                }

            companies = (
                    response_data.get("response") or
                    response_data.get("suppliers") or
                    response_data.get("data") or
                    response_data.get("companies") or
                    response_data.get("organizations") or
                    []
            )
            count_match_criteria = response_data.get("count")
            logger.info(f"Got wrapped response with {len(companies)} items")
        else:
            logger.error(f"Unexpected response type: {type(response_data)}")
            return {
                "sanitized_payload": sanitized_payload,
                "candidates": [],
                "error": "Unexpected response format"
            }

        if not companies:
            logger.info("No companies found in portfolio")
            return {
                "sanitized_payload": sanitized_payload,
                "candidates": [],
                "error": None
            }

        logger.info(f"Processing {len(companies)} companies")

        header = "| Name | D-U-N-S® | Location | Country | Status |"
        separator = "|---|---|---|---|---|"

        for candidate in companies:
            try:
                org = candidate.get("organization", candidate)
                primary_address = org.get("primaryAddress", {})
                duns = org["duns"]
                primary_name = org["primaryName"]
                locality_name = primary_address.get("addressLocality", {}).get("name", "")
                region_name = primary_address.get("addressRegion", {}).get("name", "")
                country_name = primary_address.get("addressCountry", {}).get("name", "")
                is_active = org.get("dunsControlStatus", {}).get("operatingStatus", {}).get("description", "")

                # matched_candidates.append(
                #     _serialize_model_instance(
                #         MatchedCompany(
                #             duns=org["duns"],
                #             primary_name=org["primaryName"],
                #             is_active=org.get("dunsControlStatus", {})
                #             .get("operatingStatus", {})
                #             .get("description", ""),
                #             country_code=primary_address.get("addressCountry", {}).get(
                #                 "isoAlpha2Code", ""
                #             ),
                #             country_name=primary_address.get("addressCountry", {}).get(
                #                 "name", ""
                #             ),
                #             locality_name=primary_address.get("addressLocality", {}).get(
                #                 "name", ""
                #             ),
                #             region_name=primary_address.get("addressRegion", {}).get(
                #                 "name", ""
                #             ),
                #             region_abbreviated_name=primary_address.get(
                #                 "addressRegion", {}
                #             ).get("abbreviatedName", ""),
                #             postal_code=primary_address.get("postalCode", ""),
                #         )
                #     )
                # )
                matched_candidates.append(
                    f"| {primary_name} | {duns} | {locality_name}, {region_name} | {country_name} | {is_active} |"
                )
            except Exception as e:
                logger.warning(f"Failed to parse company record: {e}")
                continue
        logger.info(f"Found {len(matched_candidates)} companies in portfolio")
        if len(matched_candidates) > 0:
            matched_candidates = [header, separator] + matched_candidates
            matched_candidates = "\n".join(matched_candidates)
            # matched_candidates = textwrap.dedent(matched_candidates)

    except ValueError as e:
        # Validation error (missing required fields, etc.)
        error_message = str(e)
        logger.error(f"Validation error: {error_message}")
    except requests.RequestException as e:
        error_message = f"Request error: {str(e)}"
        logger.error(f"Request error: {repr(e)}")
    except Exception as e:
        error_message = f"Unexpected error: {str(e)}"
        logger.error(f"Unexpected error: {repr(e)}")

    # logger.info(f"Found {len(matched_candidates)} companies in portfolio")

    return {
        "sanitized_payload": sanitized_payload,
        "total_suppliers_matching_criteria": count_match_criteria,
        "candidates": matched_candidates,
        "error": error_message
    }


if __name__ == "__main__":
    import os
    from dotenv import load_dotenv

    load_dotenv()
    is_called_from_orchestrate = False

    # Test with key=value string
    # test_payload = "countryISOAlpha2Code=US, naics=424950, pageSize=10"
    # test_payload = "inPortfolioCount=true"
    # test_payload = "unspsc=81141800, countryISOAlpha2Code=US"
    test_payload = "naics=541611, countryISOAlpha2Code=US"
    # test_payload = "naics=325510"
    # test_payload = "ssiClassLowScore=3, inPortfolioCount=True"
    # test_payload = "countryISOAlpha2Code=US"

    result = dnb_in_portfolio_supplier_discovery(test_payload, context=None)
    if result.get("error"):
        print(result)
    if "count" in result:
        print(result)
    if result.get("user_id"):
        print(f"User ID: {result['user_id']}")
    if 'total_suppliers_matching_criteria' in result:
        print(result['total_suppliers_matching_criteria'])
        # print(f"Found {len(result['candidates'])} candidates:")
        # for candidate in result['candidates']:
        #     print(f"""  - {candidate.get("primary_name")} (DUNS: {candidate.get("duns")})""")
        print(result['candidates'])
        