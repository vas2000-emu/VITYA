from typing import Any, Dict, Optional, Union

from ibm_watsonx_orchestrate.agent_builder.connections import ConnectionType, ExpectedCredentials
import requests
from requests.exceptions import RequestException

from agent_ready_tools.utils.credentials import CredentialKeys, get_tool_credentials
from agent_ready_tools.utils.systems import Systems
from agent_ready_tools.utils.tool_credentials import published_app_id

ORACLE_FUSION_CONNECTIONS = [
    ExpectedCredentials(
        app_id=published_app_id("oracle_fusion"),
        type=ConnectionType.OAUTH2_AUTH_CODE,
    ),
]


class OracleFusionClient:
    """A remote client for Oracle Fusion."""

    def __init__(self, base_url: str, bearer_token: str, version: str = "11.13.18.05"):
        """
        Args:
            base_url: The base URL for the Oracle Fusion API.
            bearer_token: The OAuth bearer token for authentication against the Oracle Fusion API.
            version: The version of Oracle Fusion API.
        """
        self.base_url = base_url
        self.headers = {
            "Authorization": f"Bearer {bearer_token}",
        }
        self.version = version

    def delete_request(
        self,
        resource_name: str,
        params: Optional[dict[str, Any]] = None,
    ) -> Union[int, Dict[str, Any]]:
        """
        Executes a DELETE request against Oracle Fusion API.

        Args:
            resource_name: The specific resource to make the request against.
            params: Query parameters for the REST API.

        Returns:
            HTTP status code on success, or an error dictionary on failure.
        """
        if params is None:
            params = {}

        response = None
        try:
            response = requests.delete(
                url=f"{self.base_url}/fscmRestApi/resources/{self.version}/{resource_name}",
                headers=self.headers,
                params=params,
            )
            response.raise_for_status()
            return response.json()
        except RequestException:
            if response is not None:
                try:
                    response_json = {"errors": response.text}
                except ValueError:
                    # handle the case where response content is not JSON (e.g. 404)
                    response_json = {"errors": "Non-JSON response"}
            else:
                # connection error, timeout, etc.
                response_json = {
                    "errors": "No response received (request failed before getting a response)"
                }
            return response_json

    def patch_request(
        self,
        resource_name: str,
        payload: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Executes a PATCH request against Oracle Fusion API.

        Args:
            resource_name: The specific resource to make the request against.
            payload: The request payload.
            params: Query parameters for the REST API.

        Returns:
            The JSON response from the Oracle Fusion REST API.
        """
        if params is None:
            params = {}
        if payload is None:
            payload = {}

        response = None
        try:
            response = requests.patch(
                url=f"{self.base_url}/fscmRestApi/resources/{self.version}/{resource_name}",
                headers=self.headers,
                params=params,
                json=payload,
            )
            response.raise_for_status()
            return response.json()
        except RequestException:
            if response is not None:
                try:
                    response_json = {"errors": response.text}
                except ValueError:
                    # handle the case where response content is not JSON (e.g. 404)
                    response_json = {"errors": "Non-JSON response"}
            else:
                # connection error, timeout, etc.
                response_json = {
                    "errors": "No response received (request failed before getting a response)"
                }
            return response_json

    def post_request(
        self,
        resource_name: str,
        params: Optional[dict[str, Any]] = None,
        payload: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Executes a POST request against Oracle Fusion API.

        Args:
            resource_name: The specific resource to make the request against.
            params: Query parameters for the REST API.
            payload: The request payload.
            headers: Optional additional headers to merge with default headers.

        Returns:
            The JSON response from the Oracle Fusion REST API.
        """
        if params is None:
            params = {}

        # Merge custom headers with default headers
        request_headers = {**self.headers}
        if headers:
            request_headers.update(headers)

        response = None
        try:
            response = requests.post(
                url=f"{self.base_url}/fscmRestApi/resources/{self.version}/{resource_name}",
                headers=request_headers,
                params=params,
                json=payload,
            )
            response.raise_for_status()
            return response.json()
        except RequestException:
            if response is not None:
                try:
                    response_json = {"errors": response.text}
                except ValueError:
                    # handle the case where response content is not JSON (e.g. 404)
                    response_json = {"errors": "Non-JSON response"}
            else:
                # connection error, timeout, etc.
                response_json = {
                    "errors": "No response received (request failed before getting a response)"
                }
            return response_json

    def get_request(
        self,
        resource_name: str,
        params: Optional[dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Executes a GET request against Oracle Fusion API.

        Args:
            resource_name: The specific resource to make the request against.
            params: Query parameters for the REST API.

        Returns:
            The JSON list response from the Oracle Fusion REST API.
        """
        if params is None:
            params = {}

        response = None
        try:
            response = requests.get(
                url=f"{self.base_url}/fscmRestApi/resources/{self.version}/{resource_name}",
                headers=self.headers,
                params=params,
            )
            response.raise_for_status()
            return response.json()
        except RequestException:
            if response is not None:
                try:
                    response_json = {"errors": response.text}
                except ValueError:
                    # handle the case where response content is not JSON (e.g. 404)
                    response_json = {"errors": "Non-JSON response"}
            else:
                # connection error, timeout, etc.
                response_json = {
                    "errors": "No response received (request failed before getting a response)"
                }
            return response_json


def get_oracle_fusion_client() -> OracleFusionClient:
    """
    Get the oracle fusion client with credentials.

    NOTE: DO NOT CALL DIRECTLY IN TESTING!

    To test, either mock this call or call the client directly.

    Returns:
        A new instance of the Oracle Fusion client.
    """
    credentials = get_tool_credentials(
        system=Systems.ORACLE_FUSION, expected_credentials=ORACLE_FUSION_CONNECTIONS
    )
    oracle_fusion_client = OracleFusionClient(
        base_url=credentials[CredentialKeys.BASE_URL],
        bearer_token=credentials[CredentialKeys.BEARER_TOKEN],
    )
    return oracle_fusion_client
