from typing import Optional, Dict, Any, List
import logging
import requests
import json
import re
from ibm_watsonx_orchestrate.agent_builder.tools import ToolPermission, tool
from ibm_watsonx_orchestrate.run import connections
from ibm_watsonx_orchestrate.client.connections import ConnectionType
from ibm_watsonx_orchestrate.run.context import AgentRun
from utils.data_services_client import DataServicesClient
from utils.matchedcompany import MatchedCompany

# Set up logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

CONNECTION_DNB = "dnb_key_value_dnb_4c6e8dad"
is_called_from_orchestrate = True

def _serialize_model_instance(model):
    """Convert pydantic/BaseModel objects into plain dictionaries."""
    if model is None:
        return None

    for attr in ("model_dump", "dict"):
        serializer = getattr(model, attr, None)
        if callable(serializer):
            try:
                return serializer()
            except TypeError:
                continue

    return getattr(model, "__dict__", model)

@tool(
    name="portfolio_check_membership_v2",
    permission=ToolPermission.READ_WRITE,
    expected_credentials=[
        {"app_id": CONNECTION_DNB, "type": ConnectionType.KEY_VALUE},
    ],
)
def portfolio_check_membership(
    search_term: str,
    country: str = '',
    locality: str = '',
    region: str = '',
    context: Optional[AgentRun] = None,
) -> Dict[str, Any]:
    """
    Takes search_term (name or DUNS) with optional 2-letter country code, locality and region, find if the entity is in clients portfolio

    Args:
        search_term: the name or DUNS to search for
        country: optional 2-letter ISO country code to search for.
        locality: optional locality to search for.
        region: optional region to search for.
        context: context of Agent run

    Returns:
        Dict[str, Any]: Dictionary with key "portfolioSearchResults" containing list of MatchedCompany objects, or "error" key if an error occurred.
    """

    if not search_term:
        return {"error": "missing duns or name"}

    try:
        if is_called_from_orchestrate:
            client_id = connections.key_value(CONNECTION_DNB).get("client_id", "")
            client_secret = connections.key_value(CONNECTION_DNB).get("client_secret", "")
        else:
            # Local testing: read from environment variables
            client_id = os.getenv("DNB_CLIENT_ID", "")
            client_secret = os.getenv("DNB_CLIENT_SECRET", "")

        # Portfolio API URL
        portfolio_api_url = "https://application-26.1zy11kva25nl.us-south.codeengine.appdomain.cloud"
        token_url = f"{portfolio_api_url}/api/v1/auth/authenticate"

        data_services_client = DataServicesClient(
            base_url=portfolio_api_url,
            token_url=token_url,
            client_id=client_id,
            client_secret=client_secret
        )
        data_services_client.authenticate_sync()
    except Exception as e:
        logger.error(f"Error during authentication: {repr(e)}")
        return {"error": str(e)}

    # get user id from request context and set in headers
    user_id = "DUMMY_USER_ID"
    if is_called_from_orchestrate and context:
        req_context = context.request_context
        user_id = req_context.get('user_id')
        if not user_id:
            logger.warning("No user ID found in request context, using DUMMY_USER_ID")
            user_id = "DUMMY_USER_ID"

    search_criteria = {
        "pageNumber": 1,
        "pageSize": 5,
    }

    if country:
        search_criteria["countryISOAlpha2Code"] = [country]
    if locality:
        search_criteria["addressLocality"] = [locality]
    if region:
        search_criteria["addressRegion"] = [region]

    if _is_nine_digit_number(search_term):
        logger.info("search term is DUNS")
        search_criteria["duns"] = [search_term.strip().replace("-", "").replace(" ", "")]
        return {"portfolioSearchResults": _check_portfolio(search_criteria, data_services_client, user_id)}
    else:
        search_criteria["primaryName"] = [search_term]
        _temp = _check_portfolio(search_criteria, data_services_client, user_id)
        search_criteria.pop("primaryName")
        search_criteria["tradeStyleName"] = [search_term]
        _temp.extend(_check_portfolio(search_criteria, data_services_client, user_id))
        return {"portfolioSearchResults": _temp}

def _is_nine_digit_number(value):
    """Check if value contains exactly 9 digits (ignoring formatting)"""
    digits = re.sub(r'\D', '', str(value))
    return len(digits) == 9 and digits.isdigit()

def _check_portfolio(payload, data_services_client, user_id) -> List:

    matched_candidates = []

    try:
        url = f"{data_services_client._base_url}/api/v2/portfolio/search/dataBlocks"

        for attempt in range(2):
            headers = {
                "Authorization": f"Bearer {data_services_client.bearer_token}",
                "Content-Type": "application/json",
                "X-User-Id": user_id,
            }
            
            response = requests.post(
                url=url,
                headers=headers,
                data=json.dumps(payload),
                timeout=30,
            )

            if response.status_code == 401:
                data_services_client.authenticate_sync()
                continue
            else:
                break

        if response.status_code != 200:
            logger.error(f"Portfolio search failed with status {response.status_code}: {response.text[:100]}")
            return []

        try:
            response_data = response.json()
        except ValueError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            return []

        for candidate in response_data.get("response", []):
            org = candidate.get("organization", {})
            primary_address = org.get("primaryAddress", {})
            is_oob = org.get("dunsControlStatus", {}).get("isOutOfBusiness")
            if is_oob:
                status = "Out of business"
            else:
                status = "Active"

            matched_candidates.append(
                _serialize_model_instance(
                    MatchedCompany(
                        duns=org.get("duns"),
                        primary_name=org.get("primaryName"),
                        is_active=status,
                        country_code=primary_address.get("addressCountry", {}).get(
                            "isoAlpha2Code", ""
                        ),
                        country_name=primary_address.get("addressCountry", {}).get(
                            "name", ""
                        ),
                        locality_name=primary_address.get("addressLocality", {}).get(
                            "name", ""
                        ),
                        region_name=primary_address.get("addressRegion", {}).get(
                            "name", ""
                        ),
                        region_abbreviated_name=primary_address.get(
                            "addressRegion", {}
                        ).get("abbreviatedName", ""),
                        postal_code=primary_address.get("postalCode", ""),
                    )
                )
            )

    except Exception as e:
        logger.error(repr(e))

    return matched_candidates


if __name__ == "__main__":
    import argparse
    import os
    from dotenv import load_dotenv

    parser = argparse.ArgumentParser()
    parser.add_argument("-s", "--search_term", required=True, help="search term")
    parser.add_argument("-c", "--country", required=False, help="country")
    parser.add_argument("-l", "--locality", required=False, help="locality")
    parser.add_argument("-r", "--region", required=False, help="region")

    args = parser.parse_args()

    load_dotenv()
    is_called_from_orchestrate = False

    results = portfolio_check_membership(args.search_term, args.country, args.locality, args.region, context=None)
    print("*********************************")
    print(results)
