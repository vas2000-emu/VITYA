# from typing import Annotated, Optional  # (Imports kept even if unused, safe for now)
import requests
import logging
import pandas as pd
import os
from io import BytesIO
from utils.data_services_client import DataServicesClient
from utils.get_minified_json import get_json
from ibm_watsonx_orchestrate.agent_builder.tools import tool, ToolPermission
from ibm_watsonx_orchestrate.agent_builder.connections import ConnectionType
from ibm_watsonx_orchestrate.run.context import AgentRun
from ibm_watsonx_orchestrate.run import connections
# Set up logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

CONNECTION_DNB = "dnb_key_value_dnb_4c6e8dad"
is_called_from_orchestrate = True


@tool(
    name="download_corporate_family_tree_v3",
    description=(
        "Download corporate family tree for the DUNS as an Excel file (.xlsx). "
        "Use this tool whenever the user asks to get full family tree, download family tree"
        "(for example: 'Provide their family tree to me', "
        "'Give me their full family tree'). "
        "The tool returns an Excel file as a downloadable attachment. "
        "CRITICAL: Do NOT display, mention, or expose any underlying download URL or storage "
        "location to the user. Only refer to the attached Excel file or the Download button."
    ),
    permission=ToolPermission.READ_ONLY,
    expected_credentials=[
        # {"app_id": CONNECTION_ELASTICSEARCH, "type": ConnectionType.KEY_VALUE},
        {"app_id": CONNECTION_DNB, "type": ConnectionType.KEY_VALUE},
    ],
)
def download_corporate_family_tree(duns_required: str, context: AgentRun) -> bytes:
    """
    Retrieve corporate family tree for the DUNS in comma delimited string of 9-digit DUNS numbers as an Excel file.

    This tool fetches the corporate family tree for the DUNS and returns the results as an in-memory Excel (.xlsx) file, ready to be
    presented to the user as a downloadable attachment.

    In error cases, the tool still returns an Excel file encoded as bytes, containing
    a single sheet with an error description instead of result rows. This keeps the
    interface consistent for the caller.

    Args:
        duns_required (str): A comma delimited string of 9-digit DUNS numbers. 

    Returns:
        bytes: The contents of an Excel (.xlsx) file encoded as bytes. In typical usage,
        this should be exposed to the user as a file download (for example, via a
        Download button), not as a raw URL or storage path. The caller should not
        display or reveal any underlying object storage location to the user.
    """

    # data services API URL
    api_url = "https://application-26.1zy11kva25nl.us-south.codeengine.appdomain.cloud"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    duns_list = []

    try:
        token = None
        if is_called_from_orchestrate:
            client_id = connections.key_value(CONNECTION_DNB).get("client_id", "")
            client_secret = connections.key_value(CONNECTION_DNB).get("client_secret", "")
        else:
            # for local testing
            client_id = os.getenv("DNB_CLIENT_ID", "")
            client_secret = os.getenv("DNB_CLIENT_SECRET", "")

        if client_id and client_secret:
            logger.info("Requesting data service API token via client_credentials grant using DNB credentials")
            token_url = f"{api_url}/api/v1/auth/authenticate"
            client = DataServicesClient(
                base_url=api_url,
                token_url=token_url,
                client_id=client_id,
                client_secret=client_secret
            )
            client.authenticate_sync()
            token = client.bearer_token
        else:
            logger.error("Missing client_id/client_secret - cannot obtain token")
            df_error = pd.DataFrame([{
                "Error": "Missing client_id/client_secret - cannot obtain token",
                "DUNS": duns
                }])
            output = BytesIO()
            df_error.to_excel(output, index=False, engine='openpyxl', sheet_name='Error')
            output.seek(0)
            return output.read()

        if token:
            headers["Authorization"] = f"Bearer {token}"
            logger.info("Added Authorization bearer token to headers")
        else:
            logger.error("Failed to fetch Bearer token")
            df_error = pd.DataFrame([{
                "Error": "Failed to fetch Bearer token",
                "DUNS": duns
                }])
            output = BytesIO()
            df_error.to_excel(output, index=False, engine='openpyxl', sheet_name='Error')
            output.seek(0)
            return output.read()

        # get user id from request context and set in headers
        user_id = "DUMMY_USER_ID"
        if is_called_from_orchestrate and context:
            req_context = context.request_context
            user_id = req_context.get('user_id')
            if not user_id:
                logger.warning("No user ID found in request context, using DUMMY_USER_ID")
                user_id = "DUMMY_USER_ID"
        
        headers["X-User-Id"] = user_id

        duns_list = [duns.strip() for duns in duns_required.split(",")]
        logger.info(f"DUNS required: {duns_list}")
        if len(duns_list) == 0:
            df_error = pd.DataFrame([{
                "Error": "No valid DUNS to retrive corporate family tree"
                }])
            output = BytesIO()
            df_error.to_excel(output, index=False, engine='openpyxl', sheet_name='Error')
            output.seek(0)
            return output.read()

        df_data = {}

        for duns in duns_list:
            family_tree_url = f"{api_url}/api/v1/familyTree/{duns}"
            payload = {"duns": duns}
            fetched_data = _fetch_family_tree_data(duns, family_tree_url, payload, headers)
            if "error" not in fetched_data:
                fetched_data = get_json({'familyTree': ['organization.fullTreeDisplayStructure']}, "familyTree", fetched_data, {})
        
            family_tree_data = fetched_data.get('organization', {}).get('fullTreeDisplayStructure', [])
            df = pd.DataFrame(family_tree_data, columns=['Index', 'Primary Name', 'D-U-N-S®', 'Roles Played', 'Country/Region', 'State/Province', 'City'])
            logger.info(f"{df.shape[0]} rows in family tree spreadsheet")
            # If no rows, return a small informational sheet
            if df.empty:
                df = pd.DataFrame([{
                    "Message": "No data returned",
                    "DUNS": duns
                }])
            df_data[duns] = df
        
        # Create Excel file in memory
        output = BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            for sheet_name, df in df_data.items():
                df.to_excel(writer, index=False, sheet_name=f'{sheet_name} Family Tree')

        output.seek(0)
        return output.read()

    except Exception as e:
        df_error = pd.DataFrame([{
            "Error": "Error occurred retrieving family tree structure",
            "Details": str(e),
            "DUNS": duns
        }])
        output = BytesIO()
        df_error.to_excel(output, index=False, engine='openpyxl', sheet_name='Error')
        output.seek(0)
        return output.read()

def _fetch_family_tree_data(duns, family_tree_url, payload, headers):

    """
    helper function to get family tree data for duns
    """

    data = {}
    try:
        response = requests.get(
            url=family_tree_url,
            headers=headers,
            params=payload,
            timeout=30,
        )
        data = response.json()
        if "error" in data:
            return {
            'inquiryDetail': {'duns': duns, 'blockIDs': ["familyTree"]},
            "error": {"errorMessage": data["error"].get("errorMessage")}, 
            }
    except Exception as e:
        return { 
            "inquiryDetail": {"duns": duns, 'blockIDs': ["familyTree"]},
            "error": {"errorMessage": str(e)},
            }

    return data


if __name__ == "__main__":
    import os
    from dotenv import load_dotenv
    # from pydantic import BaseModel

    load_dotenv()

    is_called_from_orchestrate = False
    # duns = '043964519' #has family tree data
    # duns = "148413602"  #has family tree data - small tree
    # duns = '079599939' #no family tree data
    # duns_list = ["148413602", "079599939"]
    duns_required = "148413602 , 079599939 "

    data = download_corporate_family_tree(duns_required, context=None)
    print("*" * 80)
    print("Context:", data)