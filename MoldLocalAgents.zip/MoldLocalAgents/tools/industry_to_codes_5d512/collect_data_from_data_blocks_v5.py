# from typing import List, Optional
import logging
import requests
import json

# import collections
from utils.data_services_client import DataServicesClient
from utils.get_minified_json import get_json
from ibm_watsonx_orchestrate.agent_builder.tools import ToolPermission, tool
from ibm_watsonx_orchestrate.run import connections
from ibm_watsonx_orchestrate.client.connections import ConnectionType
from ibm_watsonx_orchestrate.run.context import AgentRun
# Set up logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

CONNECTION_DNB = "dnb_key_value_dnb_4c6e8dad"
is_called_from_orchestrate = True


@tool(
    name="collect_data_from_data_blocks_v5",
    permission=ToolPermission.READ_WRITE,
    expected_credentials=[
        {"app_id": CONNECTION_DNB, "type": ConnectionType.KEY_VALUE},
    ],
)
def collect_data_from_data_blocks(duns_required: str, query: str, context: AgentRun) -> list:
    """
    Takes a comma delimited string of 9-digit DUNS numbers and a user query. Return the content that's needed to answer the query.

    Args:
        duns_required (str): A comma delimited string of 9-digit DUNS numbers.
        query (str): query string

    Returns:
        str: The content that's required to answer the query
    """

    duns_list = []
    data_context = []

    # data services API URL
    api_url = "https://application-26.1zy11kva25nl.us-south.codeengine.appdomain.cloud"
        
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    # The blocks/fields API endpoint
    url = f"{api_url}/api/v1/datablocks/fields"

    try:
        token = None
        if is_called_from_orchestrate:
            client_id = connections.key_value(CONNECTION_DNB).get("client_id", "")
            client_secret = connections.key_value(CONNECTION_DNB).get("client_secret", "")
        else:
            # for local testing
            client_id = os.getenv("DNB_CLIENT_ID", "")
            client_secret = os.getenv("DNB_CLIENT_SECRET", "")


        if client_id and client_secret:
            logger.info("Requesting data service API token via client_credentials grant using DNB credentials")
            token_url = f"{api_url}/api/v1/auth/authenticate"
            client = DataServicesClient(
                base_url=api_url,
                token_url=token_url,
                client_id=client_id,
                client_secret=client_secret
            )
            client.authenticate_sync()
            token = client.bearer_token
        else:
            logger.error("Missing client_id/client_secret - cannot obtain token")
            return {
                "context": [],
                "error": "Missing client_id/client_secret - cannot obtain token"
                }
        if token:
            headers["Authorization"] = f"Bearer {token}"
            logger.info("Added Authorization bearer token to headers")
        else:
            logger.error("Failed to fetch Bearer token")
            return {
                "context": [],
                "error": "Failed to fetch Bearer token"
                }

        # get user id from request context and set in headers
        user_id = "DUMMY_USER_ID"
        if is_called_from_orchestrate:
            req_context = context.request_context
            user_id = req_context.get('user_id')
            if not user_id:
                logger.warning("No user ID found in request context, using DUMMY_USER_ID")
                user_id = "DUMMY_USER_ID"
        
        headers["X-User-Id"] = user_id

        try:
            # gather blocks/fields needed to answer user query
            response = requests.post(
                url=f"{api_url}/api/v1/documentation/goldenquestions/search",
                headers=headers,
                data=json.dumps({"query": query}),
                timeout=30,
            )
            if response.status_code != 200:
                return {
                    "context": [],
                    "error": f"Error resolving data blocks/fields: {str(response.status_code)}"
                    }

            block_fields = response.json()
            # remove duplicate organization.duns and organization.primaryName if there 
            result_blocks = {}  
            for i, k in enumerate(block_fields.keys()):
                if i == 0:
                    result_blocks[k] = block_fields[k]
                else:
                    result_blocks[k] = [item for item in block_fields[k] if item not in ('organization.duns', 'organization.primaryName')]
            logger.info(
                f"these blocks and fields {result_blocks} will be collected to answer {query}"
            )
        except Exception as e:
            return {
                "context": [],
                "error": f"Error resolving data blocks/fields: {e}"
                }

        duns_list = [duns.strip() for duns in duns_required.split(",")]
        logger.info(f"DUNS required: {duns_list}")
        if len(duns_list) == 0:
            return {
                "context": [],
                "error": "No valid DUNS numbers to retrive data."
                } 

        family_tree_fields = result_blocks.pop("familyTree", None)
        
        if result_blocks:
            data_context = _fetch_block_data(url, duns_list, result_blocks, headers)

        if family_tree_fields:
            family_tree_data_all = []
            logger.info("fetch family tree data")
            for duns in duns_list:
                family_tree_url = f"{api_url}/api/v1/familyTree/{duns}"
                payload = {"duns": duns}
                family_tree_data = _fetch_family_tree_data(duns, family_tree_url, payload, headers)
                if "error" in family_tree_data:
                    family_tree_data_all.append([family_tree_data])
                else:
                    _temp = {"inquiryDetail": family_tree_data.get("inquiryDetail")}
                    minified_json_data = get_json({"familyTree": family_tree_fields}, "familyTree", family_tree_data, {})
                    _temp.update(minified_json_data)
                    family_tree_data_all.append([_temp])
            
            data_context += family_tree_data_all

    except Exception as e:
        logger.error(repr(e))
        return {
            "context": data_context,
            "error": f"Error obtaining data from blocks: {e}"
        }
    
    return data_context

def _fetch_family_tree_data(duns, family_tree_url, payload, headers):

    """
    helper function to get family tree data for duns
    """

    data = {}
    try:
        response = requests.get(
            url=family_tree_url,
            headers=headers,
            params=payload,
            timeout=30,
        )
        data = response.json()
        if "error" in data:
            return {
            'inquiryDetail': {'duns': duns, 'blockIDs': ["familyTree"]},
            "error": {"errorMessage": data["error"].get("errorMessage")}, 
            }
    except Exception as e:
        return { 
            "inquiryDetail": {"duns": duns, 'blockIDs': ["familyTree"]},
            "error": {"errorMessage": str(e)},
            }

    return data

def _fetch_block_data(url, duns_list, result_blocks, headers):
    """
    helper function to get dnb data blocks data
    """

    payload = {"dunsNumbers": duns_list, "requestedBlocks": result_blocks}
    final_results = []

    try:
        response = requests.post(
            url=url,
            headers=headers,
            data=json.dumps(payload),
            timeout=30,
        )
        fetch_results = response.json()
        
        if isinstance(fetch_results, list) and all([isinstance(item, list) for item in fetch_results]):
            for item in fetch_results:
                _temp = []
                for data in item:
                    if isinstance(data, dict) and "error" in data:
                        _temp.append(data["error"].get("errorDetails") or data["error"].get("errorMessage"))
                    else:
                        _temp.append(data)
                final_results.append(_temp)
        else:
            return [{
                "error": {"errorMessage": "incorrect data type returned"},
                "inquiryDetail": {"duns": duns_list, 'blockIDs': list(result_blocks.keys())}
                }]

    except Exception as e:
        return [{
            "error": {"errorMessage": str(e)}, 
            "inquiryDetail": {"duns": duns_list, 'blockIDs': list(result_blocks.keys())}
            }]

    return final_results

if __name__ == "__main__":
    import argparse
    import os
    from dotenv import load_dotenv
    # from pydantic import BaseModel, Field

    parser = argparse.ArgumentParser()
    parser.add_argument("-q", "--query", required=True, help="query")
    parser.add_argument(
        "-d", "--duns_required", required=True, help="comma delimited string of DUNS"
    )

    args = parser.parse_args()

    load_dotenv()
    # class ES_CREDS(BaseModel):
    #     username: str 
    #     password: str

    # es_creds = ES_CREDS(
    #     username=  os.getenv("ELASTICSEARCH_USER"),
    #     password=  os.getenv("ELASTICSEARCH_PASSWORD"),
    # )
    is_called_from_orchestrate = False
    
    data_context = collect_data_from_data_blocks(args.duns_required, args.query, context=None)
    print("*" * 80)
    print("Context:", data_context)
