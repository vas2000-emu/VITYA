from typing import Optional
import logging
import requests
import json
from ibm_watsonx_orchestrate.agent_builder.tools import ToolPermission, tool
from ibm_watsonx_orchestrate.run import connections
from ibm_watsonx_orchestrate.client.connections import ConnectionType
from ibm_watsonx_orchestrate.run.context import AgentRun
from utils.data_services_client import DataServicesClient
from utils.matchedcompany import MatchedCompany

# Set up logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

CONNECTION_DNB = "dnb_key_value_dnb_4c6e8dad"
is_called_from_orchestrate = True


@tool(
    name="dnb_search_by_name_v2",
    permission=ToolPermission.READ_WRITE,
    expected_credentials=[
        {"app_id": CONNECTION_DNB, "type": ConnectionType.KEY_VALUE},
    ],
)
def dnb_search_by_name_v2(
    name: str,
    country: str = '',
    locality: str = '',
    region: str = '',
    context: Optional[AgentRun] = None,
) -> list[MatchedCompany]:
    """
    Takes name with optional 2-letter country code, locality and region, finds the best matching entities

    Args:
        name (str): the name to search for
        country (str): optional 2-letter ISO country code to search for.
        locality (str): optional locality to search for.
        region (str): optional region to search for.
        context: context of Agent run

    Returns:
        list[MatchedCompany]: the best matching entities in a list.
    """

    search_criteria = {
        "searchTerm": name,
        "pageNumber": 1,
        "pageSize": 5,
    }

    if country:
        search_criteria["countryISOAlpha2Code"] = country
    if locality:
        search_criteria["addressLocality"] = locality
    if region:
        search_criteria["addressRegion"] = region

    logger.info(search_criteria)

    matched_candidates: list[MatchedCompany] = []

    try:
        if is_called_from_orchestrate:
            client_id = connections.key_value(CONNECTION_DNB).get("client_id", "")
            client_secret = connections.key_value(CONNECTION_DNB).get("client_secret", "")
        else:
            # Local testing: read from environment variables
            client_id = os.getenv("DNB_CLIENT_ID", "")
            client_secret = os.getenv("DNB_CLIENT_SECRET", "")

        # Portfolio API URL
        portfolio_api_url = "https://application-26.1zy11kva25nl.us-south.codeengine.appdomain.cloud"
        token_url = f"{portfolio_api_url}/api/v1/auth/authenticate"

        data_services_client = DataServicesClient(
            base_url=portfolio_api_url,
            token_url=token_url,
            client_id=client_id,
            client_secret=client_secret
        )
        data_services_client.authenticate_sync()
    except Exception as e:
        logger.error(repr(e))
        return matched_candidates

    # get user id from request context and set in headers
    user_id = "DUMMY_USER_ID"
    if is_called_from_orchestrate and context:
        req_context = context.request_context
        user_id = req_context.get('user_id')
        if not user_id:
            logger.warning("No user ID found in request context, using DUMMY_USER_ID")
            user_id = "DUMMY_USER_ID"

    try:
        url = f"{data_services_client._base_url}/api/v1/dnb/search/criteria"

        for attempt in range(2):
            headers = {
                "Authorization": f"Bearer {data_services_client.bearer_token}",
                "Content-Type": "application/json",
                "X-User-Id": user_id,
            }
            response = requests.post(
                url=url,
                headers=headers,
                data=json.dumps(search_criteria),
                timeout=30,
            )

            if response.status_code == 401:
                data_services_client.authenticate_sync()
                continue
            else:
                break

        if response.status_code != 200:
            logger.error(f"Search request failed with status {response.status_code}: {response.text[:100]}")
            return matched_candidates

        try:
            response_data = response.json()
        except ValueError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            return matched_candidates

        if "searchCandidates" not in response_data:
            return matched_candidates

        if not response_data["searchCandidates"]:
            return matched_candidates

        for candidate in response_data["searchCandidates"]:
            org = candidate.get("organization", {})
            primary_address = org.get("primaryAddress", {})
            is_oob = org.get("dunsControlStatus", {}).get("isOutOfBusiness")
            if is_oob:
                status = "Out of business"
            else:
                status = "Active"

            matched_candidates.append(
                MatchedCompany(
                    duns=org.get("duns"),
                    primary_name=org.get("primaryName"),
                    is_active=status,
                    country_code=primary_address.get("addressCountry", {}).get(
                        "isoAlpha2Code", ""
                    ),
                    country_name=primary_address.get("addressCountry", {}).get(
                        "name", ""
                    ),
                    locality_name=primary_address.get("addressLocality", {}).get(
                        "name", ""
                    ),
                    region_name=primary_address.get("addressRegion", {}).get(
                        "name", ""
                    ),
                    region_abbreviated_name=primary_address.get(
                        "addressRegion", {}
                    ).get("abbreviatedName", ""),
                    postal_code=primary_address.get("postalCode", ""),
                )
            )

    except Exception as e:
        logger.error(repr(e))

    return matched_candidates


if __name__ == "__main__":
    import argparse
    import os
    from dotenv import load_dotenv

    parser = argparse.ArgumentParser()
    parser.add_argument("-n", "--name", required=True, help="name")
    parser.add_argument("-c", "--country", required=False, help="country")
    parser.add_argument("-l", "--locality", required=False, help="locality")
    parser.add_argument("-r", "--region", required=False, help="region")

    args = parser.parse_args()

    load_dotenv()
    is_called_from_orchestrate = False

    candidates = dnb_search_by_name_v2(args.name, args.country, args.locality, args.region, context=None)
    print("candidates:", candidates)
