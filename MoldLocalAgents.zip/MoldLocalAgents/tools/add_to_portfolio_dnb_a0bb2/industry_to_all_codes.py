import logging
import re
import os
import json
from typing import Any, List, Dict, Optional
from ibm_watsonx_orchestrate.agent_builder.tools import ToolPermission, tool
import requests
from ibm_watsonx_orchestrate.run import connections
from ibm_watsonx_orchestrate.client.connections import ConnectionType
from ibm_watsonx_orchestrate.run.context import AgentRun
from utils.data_services_client import DataServicesClient

# Logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - [%(levelname)s] - %(message)s"
)
logger = logging.getLogger(__name__)

CONNECTION_DNB = "dnb_key_value_dnb_4c6e8dad"
UNSPSC_LIMIT = 1
OTHER_CODES_LIMIT = 5
is_called_from_orchestrate = True


@tool(
    name="industry_to_codes",
    description="Convert industry term to industry codes",
    permission=ToolPermission.READ_WRITE,
    expected_credentials=[
        {"app_id": CONNECTION_DNB, "type": ConnectionType.KEY_VALUE},
    ],
)
def industry_to_all_codes(
    query: str,
    context: AgentRun,
) -> Dict[str, Any]:
    """
    Takes a textual query and returns a dictionary with candidate industry codes and error status.

    Args:
        query: free-text industry query
        context: context of Agent run

    Returns:
        Dictionary with keys:
            - industry_codes: List of dictionaries with keys: industry_code, description, type
            - error: Optional error message string
    """

    candidates = []
    error = None

    # Data Services API URL
    api_url = "https://application-26.1zy11kva25nl.us-south.codeengine.appdomain.cloud"
    codes_url = f"{api_url}/api/v1/industryCodes/search"
    unspsc_url = f"{api_url}/api/unspc/search"
    headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    # Obtain data service API token using DNB client credentials
    try:
        token = None
        if is_called_from_orchestrate:
            dnb_creds = connections.key_value(CONNECTION_DNB)
            client_id = dnb_creds.get("client_id", "")
            client_secret = dnb_creds.get("client_secret", "")
        else:
            # Local testing: read from environment variables
            client_id = os.getenv("DNB_CLIENT_ID", "")
            client_secret = os.getenv("DNB_CLIENT_SECRET", "")
        
        if client_id and client_secret:
            logger.info("Requesting data service API token via client_credentials grant using DNB credentials")
            token_url = f"{api_url}/api/v1/auth/authenticate"
            client = DataServicesClient(
                base_url=api_url,
                token_url=token_url,
                client_id=client_id,
                client_secret=client_secret
            )
            client.authenticate_sync()
            token = client.bearer_token
        else:
            logger.error("Missing client_id/client_secret - cannot obtain token")
            return {
                "industry_codes": [],
                "error": "Missing client_id/client_secret - cannot obtain token"
                }
        
        if token:
            headers["Authorization"] = f"Bearer {token}"
            logger.info("Added Authorization bearer token to headers")
        else:
            logger.error("Failed to fetch Bearer token")
            return {
                "industry_codes": [],
                "error": "Failed to fetch Bearer token"
                }
    except Exception as e:
        logger.error(f"Error obtaining data service API token: {e}")
        return {
            "industry_codes": [],
            "error": f"Error obtaining data service API token: {e}"
        }
    
    # get user id from request context and set in headers
    user_id = "DUMMY_USER_ID"
    if is_called_from_orchestrate and context:
        req_context = context.request_context
        user_id = req_context.get('user_id')
        if not user_id:
            logger.warning("No user ID found in request context, using DUMMY_USER_ID")
            user_id = "DUMMY_USER_ID"
            
    headers["X-User-Id"] = user_id
    
    # Remove suppliers/supplier and companies/company (singular/plural, case insensitive)
    query = re.sub(r'\b(suppliers?|companies?)\b', '', query, flags=re.IGNORECASE)
    
    # Clean up extra whitespace
    query = re.sub(r'\s+', ' ', query).strip()
    
    # Validate query after preprocessing
    if not query:
        return {
            "industry_codes": [],
            "error": "Query is empty after preprocessing"
        }

    try:
        # search unspsc codes
        unspsc_results = _code_search(unspsc_url, query, headers, UNSPSC_LIMIT)
        # search sic4, sic8 and naics codes
        other_codes_results = _code_search(codes_url, query, headers, OTHER_CODES_LIMIT)

        candidates = other_codes_results + unspsc_results
        if len(candidates) == 0:
            error = "not able to find relevant industry codes"

    except Exception as e:
        error = repr(e)
        logger.error(repr(e))

    return {
        "industry_codes": candidates,
        "error": error
    }

def _code_search(url: str, query: str, headers: Dict[str, str], limit: int) -> List[Dict[str, Any]]:
    """
    helper function to search industry codes

    """
    results = []

    try:
        response = requests.post(
            url=url,
            headers=headers,
            data=json.dumps({"query": query, "rerank": True, "textBoost": 1}),
            timeout=30,
        )

        if response.status_code != 200:
            logger.error(f"Industry code conversion returned with {response.status_code}: {response.text}")
            return []

        try:
            response_data = response.json()
        except ValueError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            return []
        
        logger.info(f"Response type: {type(response_data)}")

        if isinstance(response_data, list):
            logger.info(f"Got direct array with {len(response_data)} items")
            # Normalize each item and build IndustryCode objects
            for item in response_data:
                if not isinstance(item, dict):
                    logger.warning(f"Skipping non-dict item")
                    continue

                code = str(item.get("code", ""))
                desc = str(item.get("description", item.get("desc", "")))
                desc = desc.replace("UN Standards Products & Services Code : ", "")
                if "unspc/search" in url:
                    code_type = "unspsc"
                else:
                    code_type = str(item.get("type", ""))
                if code_type == "ussicv8":
                    code_type = "usSicV8"
                if code_type == "ussicv4":
                    code_type = "usSicV4"

                if not desc and not code:
                    logger.warning(f"Skipping item with no title/code")
                    continue
                
                results.append(
                    {
                        'description': desc,
                        'industry_code': code,
                        'type': code_type
                    }
                )
        else:
            logger.error(f"Unexpected JSON shape: {type(response_data).__name__}")
            return []

    except Exception as e:
        logger.error(repr(e))
        return []

    return results[:limit]


if __name__ == "__main__":
    import argparse
    from dotenv import load_dotenv
    # Env config
    load_dotenv()
    is_called_from_orchestrate = False   

    try:
        parser = argparse.ArgumentParser()
        parser.add_argument("-q", "--query", required=True, help="industry query text")
        args = parser.parse_args()

        codes = industry_to_all_codes(args.query, None)
        for code in codes.get("industry_codes", []):
            print(code)
    except Exception as e:
        logger.error(repr(e))