import asyncio
import aiohttp
import ssl
import certifi
import logging
from typing import Optional, List, Tuple, Dict, Any
from utils.data_services_client import DataServicesClient
from ibm_watsonx_orchestrate.agent_builder.tools import ToolPermission, tool
from ibm_watsonx_orchestrate.run import connections
from ibm_watsonx_orchestrate.client.connections import ConnectionType
from ibm_watsonx_orchestrate.run.context import AgentRun

# Set up logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

CONNECTION_DNB = "dnb_key_value_dnb_4c6e8dad"
is_called_from_orchestrate = True
# Standard data blocks
APPROVED_BLOCK_IDS = "companyfinancials_L4_v3,companyinfo_L4_v1,eventfilings_L3_v1,principalscontacts_L3_v2,paymentinsight_L4_v1,diversityinsight_L3_v1,esginsight_L3_v2,financialstrengthinsight_L3_v1,thirdpartyriskinsight_L1_v4,hierarchyconnections_L1_v1"


@tool(
    name="add_to_portfolio_dnb",
    permission=ToolPermission.READ_ONLY,
    expected_credentials=[
         {"app_id": CONNECTION_DNB, "type": ConnectionType.KEY_VALUE},
    ]
)
def add_to_portfolio_v3(duns_required: str, context: AgentRun) -> Dict[str, Any]:
    """
    Takes a comma delimited string of 9-digit DUNS numbers and add them into purchased DUNS portfolio

    Args:
        duns_required (str): a comma delimited string of 9-digit DUNS numbers
        context: Optional context of Agent run

    Returns:
        Dict[str, Any]: Dictionary mapping DUNS numbers to their results (tenant_id or error message)
    """

    # Filter out empty strings after splitting
    duns_list = [duns.strip() for duns in duns_required.split(",") if duns.strip()]
    
    if len(duns_list) == 0:
        return {
            "error": "No valid DUNS numbers to add to portfolio."
            }

    return asyncio.run(_add_to_portfolio_v3_async(duns_list, context))


async def _add_to_portfolio_v3_async(duns_list: List[str], context: AgentRun) -> Dict[str, Any]:
    """
    Async implementation of add_to_portfolio_v3
    """
    messages_to_return = {}

    try:
        if is_called_from_orchestrate:
            client_id = connections.key_value(CONNECTION_DNB).get("client_id", "")
            client_secret = connections.key_value(CONNECTION_DNB).get("client_secret", "")
        else:
            # Local testing: read from environment variables
            import os
            client_id = os.getenv("DNB_CLIENT_ID", "")
            client_secret = os.getenv("DNB_CLIENT_SECRET", "")

        # Portfolio API URL
        portfolio_api_url = "https://application-26.1zy11kva25nl.us-south.codeengine.appdomain.cloud"
        token_url = f"{portfolio_api_url}/api/v1/auth/authenticate"

        data_services_client = DataServicesClient(
            base_url=portfolio_api_url,
            token_url=token_url,
            client_id=client_id,
            client_secret=client_secret
        )
        await data_services_client.authenticate()

        url = f"{data_services_client._base_url}/api/v1/portfolio/rum"

        block_ids = APPROVED_BLOCK_IDS.split(",")
        # print(f"blocks to add {block_ids}")

        headers = {
                "Authorization": f"Bearer {data_services_client.bearer_token}",
                "Content-Type": "application/json",
            }
        # get user id from request context and set in headers
        user_id = "DUMMY_USER_ID"
        if is_called_from_orchestrate and context:
            req_context = context.request_context
            user_id = req_context.get('user_id')
            if not user_id:
                user_id = "DUMMY_USER_ID"
        
        headers["X-User-Id"] = user_id

        # Create async helper function for each DUNS request
        async def add_single_duns(session: aiohttp.ClientSession, duns: str) -> Tuple[str, str]:
            """Add a single DUNS to portfolio"""
            payload = {
                "duns": duns,
                "blockIds": block_ids
            }

            try:
                timeout = aiohttp.ClientTimeout(total=30)
                async with session.post(
                    url=url,
                    headers=headers,
                    json=payload,
                    timeout=timeout,
                ) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        return (duns, f"error occurred: {response.status} - {error_text[:100]}")
                    else:
                        try:
                            result = await response.json()
                            return (duns, result.get("tenant_id", ""))
                        except (aiohttp.ContentTypeError, ValueError) as e:
                            return (duns, f"error occurred: Failed to parse JSON response - {str(e)}")
            except Exception as e:
                return (duns, f"error occurred: {str(e)}")

        # Create SSL context and session
        ssl_context = ssl.create_default_context(cafile=certifi.where())
        connector = aiohttp.TCPConnector(ssl=ssl_context)

        async with aiohttp.ClientSession(connector=connector) as session:
            # Create tasks for all DUNS requests
            tasks = [add_single_duns(session, duns) for duns in duns_list]
            # Execute all requests concurrently
            results = await asyncio.gather(*tasks)
            
            # Build result dictionary
            for duns, result in results:
                messages_to_return[duns] = result

        return messages_to_return
    except Exception as e:
        logger.error(f"Error in _add_to_portfolio_v3_async: {repr(e)}")
        return {"error": "not able to add DUNS to portfolio: " + str(e)}



if __name__ == "__main__":
    import os
    from dotenv import load_dotenv

    load_dotenv()
    is_called_from_orchestrate = False

    # duns_list = ["216717306", "141456991"]
    duns_list = ['001381284',
                '001339159',
                '001316330',
                '008382293',
                '118129570',
                '808784326',
                '101916062',
                '031994218',
                '113795624',
                '781402466',
                '078279641',
                '829518328',
                '005094842',
                '186064960',
                '613194799',
                '142292973',
                '015013683',
                '079153956',
                '117552923',
                '117553944']
    # duns_list = ["148284255", "423963466"]

    res = asyncio.run(_add_to_portfolio_v3_async(duns_list, context=None))
    print(res)