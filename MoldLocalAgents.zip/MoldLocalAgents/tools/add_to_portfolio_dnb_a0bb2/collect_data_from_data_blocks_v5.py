import logging
import os
import requests
import json

from utils.data_services_client import DataServicesClient
from utils.get_minified_json import get_json
from ibm_watsonx_orchestrate.agent_builder.tools import ToolPermission, tool
from ibm_watsonx_orchestrate.run import connections
from ibm_watsonx_orchestrate.client.connections import ConnectionType
from ibm_watsonx_orchestrate.run.context import AgentRun

# Set up logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

CONNECTION_DNB = "dnb_key_value_dnb_4c6e8dad"
is_called_from_orchestrate = True


@tool(
    name="collect_data_from_data_blocks_dnb",
    permission=ToolPermission.READ_WRITE,
    expected_credentials=[
        {"app_id": CONNECTION_DNB, "type": ConnectionType.KEY_VALUE},
    ],
)
def collect_data_from_data_blocks(duns_required: str, query: str, context: AgentRun) -> list:
    """
    Takes a comma delimited string of 9-digit DUNS numbers and a user query. Return the content that's needed to answer the query.

    Args:
        duns_required (str): A comma delimited string of 9-digit DUNS numbers.
        query (str): query string
        context (AgentRun): context of Agent run

    Returns:
        list: A list of data context items. On error, returns a list containing a dict with "error" key.
    """

    data_context = []

    # data services API URL
    api_url = "https://application-26.1zy11kva25nl.us-south.codeengine.appdomain.cloud"
        
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    # The blocks/fields API endpoint
    url = f"{api_url}/api/v1/datablocks/fields"

    try:
        token = None
        if is_called_from_orchestrate:
            client_id = connections.key_value(CONNECTION_DNB).get("client_id", "")
            client_secret = connections.key_value(CONNECTION_DNB).get("client_secret", "")
        else:
            # for local testing
            client_id = os.getenv("DNB_CLIENT_ID", "")
            client_secret = os.getenv("DNB_CLIENT_SECRET", "")


        if client_id and client_secret:
            logger.info("Requesting data service API token via client_credentials grant using DNB credentials")
            token_url = f"{api_url}/api/v1/auth/authenticate"
            client = DataServicesClient(
                base_url=api_url,
                token_url=token_url,
                client_id=client_id,
                client_secret=client_secret
            )
            client.authenticate_sync()
            token = client.bearer_token
        else:
            logger.error("Missing client_id/client_secret - cannot obtain token")
            return [{"error": "Missing client_id/client_secret - cannot obtain token"}]
        if token:
            headers["Authorization"] = f"Bearer {token}"
            logger.info("Added Authorization bearer token to headers")
        else:
            logger.error("Failed to fetch Bearer token")
            return [{"error": "Failed to fetch Bearer token"}]

        # get user id from request context and set in headers
        user_id = "DUMMY_USER_ID"
        if is_called_from_orchestrate and context:
            req_context = context.request_context
            user_id = req_context.get('user_id')
            if not user_id:
                logger.warning("No user ID found in request context, using DUMMY_USER_ID")
                user_id = "DUMMY_USER_ID"
        
        headers["X-User-Id"] = user_id

        # gather blocks/field paths needed to answer user query from fastapi endpoint
        fastapi_url = "https://dnb-block-field-paths.1zy11kva25nl.us-south.codeengine.appdomain.cloud"
        fastapi_token_url = f"{fastapi_url}/api/authenticate"
        fastapi_search_url = f"{fastapi_url}/api/documentation/goldenquestions/search"
        
        try:
            # Authenticate with FastAPI endpoint
            token_response = requests.post(
                url=fastapi_token_url,
                headers={
                    "accept": "application/json",
                    "Content-Type": "application/json"
                },
                data=json.dumps({"client_id": client_id, "client_secret": client_secret}),
                timeout=30,
            )
            
            if token_response.status_code != 200:
                error_text = token_response.text[:500]
                logger.error(f"FastAPI authentication failed with status {token_response.status_code}: {error_text}")
                return [{"error": f"Error authenticating: status {token_response.status_code}"}]
            
            try:
                token_data = token_response.json()
                fastapi_token = token_data.get("access_token")
                if not fastapi_token:
                    logger.error("access_token not found in FastAPI authentication response")
                    return [{"error": "Error authenticating: access_token not found"}]
            except ValueError as e:
                logger.error(f"Failed to parse FastAPI authentication response as JSON: {e}")
                return [{"error": "Error authenticating: invalid JSON response"}]
            
            # Search for relevant blocks/fields
            fastapi_response = requests.post(
                url=fastapi_search_url,
                headers={
                    "accept": "application/json",
                    "Authorization": f"Bearer {fastapi_token}",
                    "Content-Type": "application/json"
                },
                data=json.dumps({"query": query}),
                timeout=30,
            )
            
            if fastapi_response.status_code != 200:
                error_text = fastapi_response.text[:500]
                logger.error(f"FastAPI search failed with status {fastapi_response.status_code}: {error_text}")
                return [{"error": f"Error resolving data blocks/fields: status {fastapi_response.status_code}"}]
            
            try:
                block_fields = fastapi_response.json()
            except ValueError as e:
                logger.error(f"Failed to parse FastAPI search response as JSON: {e}")
                return [{"error": "Error resolving data blocks/fields: invalid JSON response"}]
            
            if block_fields.get("error"):
                error_msg = block_fields.get("error")
                logger.error(f"FastAPI returned error: {error_msg}")
                return [{"error": f"Error resolving data blocks/fields: {error_msg}"}]
            
            result_blocks = block_fields.get("result_blocks", {})
            if not result_blocks:
                logger.warning("No data blocks/fields returned from FastAPI search")
                return [{"error": "No data blocks/fields to collect to answer the query."}]
            
            logger.info(f"These blocks and fields {result_blocks} will be collected to answer {query}")
            
        except Exception as e:
            logger.error(f"Error resolving data blocks/fields: {e}")
            return [{"error": f"Error resolving data blocks/fields: {str(e)}"}]

        duns_list = [duns.strip() for duns in duns_required.split(",")]
        logger.info(f"DUNS required: {duns_list}")
        if len(duns_list) == 0:
            return [{"error": "No valid DUNS numbers to retrieve data."}] 

        family_tree_fields = result_blocks.pop("familyTree", None)
        
        if result_blocks:
            data_context = _fetch_block_data(url, duns_list, result_blocks, headers)

        if family_tree_fields:
            family_tree_data_all = []
            logger.info("fetch family tree data")
            for duns in duns_list:
                family_tree_url = f"{api_url}/api/v1/familyTree/{duns}"
                payload = {"duns": duns}
                family_tree_data = _fetch_family_tree_data(duns, family_tree_url, payload, headers)
                if "error" in family_tree_data:
                    family_tree_data_all.append([family_tree_data])
                else:
                    _temp = {"inquiryDetail": family_tree_data.get("inquiryDetail")}
                    minified_json_data = get_json({"familyTree": family_tree_fields}, "familyTree", family_tree_data, {})
                    _temp.update(minified_json_data)
                    family_tree_data_all.append([_temp])
            
            data_context += family_tree_data_all

    except Exception as e:
        logger.error(repr(e))
        return data_context + [{"error": f"Error obtaining data from blocks: {e}"}]
    
    return data_context

def _fetch_family_tree_data(duns, family_tree_url, payload, headers):

    """
    helper function to get family tree data for duns
    """

    data = {}
    try:
        response = requests.get(
            url=family_tree_url,
            headers=headers,
            params=payload,
            timeout=30,
        )
        
        if response.status_code != 200:
            error_text = response.text[:500]
            logger.error(f"Family tree request failed with status {response.status_code}: {error_text}")
            return {
                'inquiryDetail': {'duns': duns, 'blockIDs': ["familyTree"]},
                "error": {"errorMessage": f"Request failed with status {response.status_code}"}, 
            }
        
        try:
            data = response.json()
        except ValueError as e:
            logger.error(f"Failed to parse family tree response as JSON: {e}")
            return {
                'inquiryDetail': {'duns': duns, 'blockIDs': ["familyTree"]},
                "error": {"errorMessage": "Invalid JSON response"}, 
            }
        
        if "error" in data:
            return {
                'inquiryDetail': {'duns': duns, 'blockIDs': ["familyTree"]},
                "error": {"errorMessage": data["error"].get("errorMessage")}, 
            }
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error when fetching family tree data: {e}")
        return { 
            "inquiryDetail": {"duns": duns, 'blockIDs': ["familyTree"]},
            "error": {"errorMessage": str(e)},
            }
    except Exception as e:
        logger.error(f"Unexpected error when fetching family tree data: {e}")
        return { 
            "inquiryDetail": {"duns": duns, 'blockIDs': ["familyTree"]},
            "error": {"errorMessage": str(e)},
            }

    return data

def _fetch_block_data(url, duns_list, result_blocks, headers):
    """
    helper function to get dnb data blocks data
    """

    payload = {"dunsNumbers": duns_list, "requestedBlocks": result_blocks}
    final_results = []

    try:
        response = requests.post(
            url=url,
            headers=headers,
            data=json.dumps(payload),
            timeout=30,
        )
        
        if response.status_code != 200:
            error_text = response.text[:500]
            logger.error(f"Data blocks request failed with status {response.status_code}: {error_text}")
            return [{
                "error": {"errorMessage": f"Request failed with status {response.status_code}"},
                "inquiryDetail": {"duns": duns_list, 'blockIDs': list(result_blocks.keys())}
            }]
        
        try:
            fetch_results = response.json()
        except ValueError as e:
            logger.error(f"Failed to parse data blocks response as JSON: {e}")
            return [{
                "error": {"errorMessage": "Invalid JSON response"},
                "inquiryDetail": {"duns": duns_list, 'blockIDs': list(result_blocks.keys())}
            }]
        
        if isinstance(fetch_results, list) and all(isinstance(item, list) for item in fetch_results):
            for item in fetch_results:
                _temp = []
                for data in item:
                    if isinstance(data, dict) and "error" in data:
                        _temp.append(data["error"].get("errorDetails") or data["error"].get("errorMessage"))
                    else:
                        _temp.append(data)
                final_results.append(_temp)
        else:
            return [{
                "error": {"errorMessage": "incorrect data type returned"},
                "inquiryDetail": {"duns": duns_list, 'blockIDs': list(result_blocks.keys())}
                }]

    except requests.exceptions.RequestException as e:
        logger.error(f"Request error when fetching data blocks: {e}")
        return [{
            "error": {"errorMessage": str(e)}, 
            "inquiryDetail": {"duns": duns_list, 'blockIDs': list(result_blocks.keys())}
            }]
    except Exception as e:
        logger.error(f"Unexpected error when fetching data blocks: {e}")
        return [{
            "error": {"errorMessage": str(e)}, 
            "inquiryDetail": {"duns": duns_list, 'blockIDs': list(result_blocks.keys())}
            }]

    return final_results

if __name__ == "__main__":
    import argparse
    import os
    from dotenv import load_dotenv

    parser = argparse.ArgumentParser()
    parser.add_argument("-q", "--query", required=True, help="query")
    parser.add_argument(
        "-d", "--duns_required", required=True, help="comma delimited string of DUNS"
    )

    args = parser.parse_args()

    load_dotenv()
    is_called_from_orchestrate = False
    
    data_context = collect_data_from_data_blocks(args.duns_required, args.query, context=None)
    print("*" * 80)
    print("Context:", data_context)
