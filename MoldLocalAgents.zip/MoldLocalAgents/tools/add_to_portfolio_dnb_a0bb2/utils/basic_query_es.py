import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)


def basic_query(
    es_client: Any,
    index_to_search: str,
    query: str,
    embedding_model: Any,
    vector_field: str,
    output_fields: List[str],
    top_k: int = 5,
    verbose: bool = False,
):
    """
    Args:
        es_client: elasticsearch client
        index_to_search: elasticsearch index to search
        query: query string
        embedding_model: embedding model used to embed the query string
        vector_field: name of the dense vector field used for ANN
        output_fields: list of source fields to return
        top_k: number of results to return
        verbose: print results or not

    Return:
        List[Dictionary]
    """

    final_results: List[Dict[str, Any]] = []

    try:
        # Vectorize query text
        query_vector = embedding_model.embed_query(query)
        if isinstance(query_vector, list):
            pass
        else:
            # Some embedders return numpy arrays
            try:
                query_vector = query_vector.tolist()
            except Exception:
                query_vector = list(query_vector)

        body = {
            "knn": {
                "field": vector_field,
                "query_vector": query_vector,
                "k": int(top_k),
                # Use a generous candidate pool to improve recall
                "num_candidates": max(int(top_k) * 20, 100),
            },
            "_source": output_fields,
            "size": int(top_k),
        }

        try:
            response = es_client.search(index=index_to_search, body=body)

            hits = response.get("hits", {}).get("hits", [])
            for h in hits:
                temp: Dict[str, Any] = {"score": h.get("_score", 0.0)}
                source = h.get("_source", {}) or {}
                for field in output_fields:
                    temp[field] = source.get(field)
                final_results.append(temp)

            if verbose:
                logger.info("Query: %s", query)
                logger.info("Results:")
                for j, item in enumerate(final_results):
                    logger.info("\tRank: %s Data: %s", j + 1, item)
        except Exception as e:
            logger.error(repr(e))
            return []
    except Exception as e:
        logger.info(repr(e))

    return final_results

if __name__ == "__main__":
    import argparse
    import os
    from dotenv import load_dotenv
    from elasticsearch import Elasticsearch
    from ibm_watsonx_ai import APIClient, Credentials
    from ibm_watsonx_ai.foundation_models.embeddings import Embeddings
    from ibm_watsonx_ai.metanames import EmbedTextParamsMetaNames as EmbedParams

    parser = argparse.ArgumentParser()
    parser.add_argument("-q", "--query", required=True, help="query")

    args = parser.parse_args()

    load_dotenv()
    api_key = os.getenv("WATSONX_API_KEY")
    project_id = os.getenv("PROJECT_ID")
    credentials = Credentials(
            url="https://us-south.ml.cloud.ibm.com",
            api_key=api_key,
        )
    wx_client = APIClient(credentials, project_id=project_id)

    embed_params = {
        EmbedParams.TRUNCATE_INPUT_TOKENS: 512,
        EmbedParams.RETURN_OPTIONS: {"input_text": True},
    }
    # dim 768
    embedding_model = Embeddings(
        api_client=wx_client,
        model_id="ibm/granite-embedding-278m-multilingual",
        params=embed_params,
    )

    es_client = Elasticsearch(
            hosts=os.getenv('ELASTICSEARCH_URL'),
            basic_auth=(os.getenv('ELASTICSEARCH_USER'), os.getenv('ELASTICSEARCH_PASSWORD')),
            ca_certs='./src/tools/ca_bundle.pem',
            verify_certs=True,
            request_timeout=3600,
        )
    print("Elasticsearch client established.")
    
    # results = basic_query(es_client, "dnb_golden_questions", args.query, embedding_model, "embeddings", ["Question", "RA_Field_Mapping", "dataBlock", "Type"], 5, False)
    results = basic_query(es_client, "dnb_blocks_dictionary", args.query, embedding_model, "embedding", ["text", "jsonPath", "dataBlock"], 5, False)
    print("Results:", results)
