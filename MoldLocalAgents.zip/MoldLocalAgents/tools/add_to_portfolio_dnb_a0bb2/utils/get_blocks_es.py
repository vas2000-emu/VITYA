from operator import itemgetter
from utils.basic_query_es import basic_query
from typing import Any
import logging

logger = logging.getLogger(__name__)


def query_flow(
    es_client: Any, query: str, embedding_model: Any
):
    """
    function to search both dnb_golden_questions and dnb_blocks_dictionary indices in Elasticsearch for query
    Args:
        query: string
    Return:
        List[Dictionary]
    """
    combined_sorted = []

    try:
        mapping_results = basic_query(
            es_client,
            "dnb_golden_questions",
            query,
            embedding_model,
            "embeddings",
            ["Question", "RA_Field_Mapping", "dataBlock", "Type"],
            top_k=7,
            verbose=False,
        )
    except Exception as e:
        logger.info(repr(e))
        mapping_results = []

    try:
        dictionary_results = basic_query(
            es_client,
            "dnb_blocks_dictionary",
            query,
            embedding_model,
            "embedding",
            ["text", "jsonPath", "dataBlock"],
            top_k=3,
            verbose=False,
        )
    except Exception as e:
        logger.info(repr(e))
        dictionary_results = []

    combined = mapping_results.copy()
    combined.extend(dictionary_results)
    if len(combined) > 0:
        combined_sorted = sorted(combined, key=itemgetter("score"), reverse=True)

    return combined_sorted


def rerank_docs(query, retrieved_docs, reranker_model):
    """
    helper function to rerank results with cross encoder
    Args:
        query: query string
        retrieved_docs: list of retrieved documents
        reranker_model: reranker model to use for rerank the choices
    Return:
        list of reranked documents
    """
    # print(query)
    try:
        rerank_inputs = []
        for r in retrieved_docs:
            if "Question" in r:
                rerank_inputs.append(r["Question"])
            elif "text" in r:
                rerank_inputs.append(r["text"])

        rerank_outputs = reranker_model.generate(query=query, inputs=rerank_inputs)
        reranked_results = [
            retrieved_docs[r["index"]] for r in rerank_outputs["results"]
        ]
        return reranked_results
    except Exception as e:
        logger.error(repr(e))
        logger.info(
            "reranker fails to generate results. use direct vector search results"
        )
        return retrieved_docs


def search_with_rerank(
    es_client: Any, query: str, embedding_model: Any, reranker_model: Any
):
    """
    function to find the most relevant {block: fields} to answer query
    Parameters:
        es_client: Elasticsearch client
        embedding_model: embedding model to use for embed the query string. should be the same as the one used during collection creation
        reranker_model: reranker model to use for rerank the choices
        query: query string
    Return:
        search_results: dict, combined search results
    """
    search_results = {}

    try:
        combined_sorted = query_flow(
            es_client,
            query,
            embedding_model,
        )

        choices_sorted = []
        if len(combined_sorted) > 0:
            max_score = combined_sorted[0]["score"]
            if max_score >= 0.999:
                # perfect match, just use the perfect match
                choices_sorted = combined_sorted[:1]
            else:
                # rerank the choices from embedding model
                choices_sorted = rerank_docs(query, combined_sorted, reranker_model)[:2]
                # print(choices_sorted)

        for i, choice in enumerate(choices_sorted):
            if "RA_Field_Mapping" in choice:
                # golden search
                jsonPaths = choice["RA_Field_Mapping"]
                dataBlocks = choice["dataBlock"]
                types = choice["Type"]
                jsonPaths = jsonPaths.split(",")
                dataBlocks = dataBlocks.split(",")
                types = types.split(",")
                assert len(jsonPaths) == len(dataBlocks)
                assert len(jsonPaths) == len(types)
                for b, p in zip(dataBlocks, jsonPaths):
                    if b in search_results:
                        # could use set but need to keep order
                        if p not in search_results[b]:
                            search_results[b].append(p)
                    else:
                        search_results[b] = [p]
            else:
                # dictionary search
                dataBlock = choice["dataBlock"]
                jsonPath = choice["jsonPath"]

                if dataBlock in search_results:
                    if jsonPath not in search_results[dataBlock]:
                        search_results[dataBlock].append(jsonPath)
                else:
                    search_results[dataBlock] = [jsonPath]

        # always add organization.duns and organization.primaryName
        for key in search_results:
            # print(key)
            if "organization.primaryName" not in search_results[key]:
                search_results[key].insert(0, "organization.primaryName")
            if "organization.duns" not in search_results[key]:
                search_results[key].insert(0, "organization.duns")
            break
    except Exception as e:
        logger.error(repr(e))

    return search_results


def get_support_metadata(
    es_client: Any, result_blocks
):
    """
    function to gather metadata for score fields
    Args:
        es_client: Elasticsearch client
        result_blocks (dictionary): vector search results with best matching blocks and fields.

    Return:
        JSON object
    """
    metadata = {}
    for k, v in result_blocks.items():
        temp = {}
        for p in v:
            if "score" in p.lower() and "scoredate" not in p.lower() and "datadepth" not in p.lower():
                # keyword search using dnb_blocks_dictionary index against jsonPath field to find description
                results_from_meta = es_client.search(
                    index="dnb_blocks_dictionary",
                    body={
                        "query": {
                            "match": {
                                "jsonPath": p
                            }
                        }
                    }
                )
                if len(results_from_meta["hits"]["hits"]) > 0:  # make sure it's a direct match
                    description = results_from_meta["hits"]["hits"][0]["_source"]["description"]
                    fields = p.split(".")
                    for i, f in enumerate(reversed(fields)):
                        if i == 0:
                            temp_data = {f + "Description": description}
                        else:
                            temp_data = {f: temp_data}
                    temp[p] = temp_data
        if len(temp) > 0:
            metadata[k] = temp
    return metadata