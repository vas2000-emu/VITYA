from typing import Optional
from pydantic import BaseModel, Field


class MatchedCompany(BaseModel):
    """Represents a single company."""

    duns: str = Field(pattern=r"^\d{9}$")
    primary_name: str
    is_active: str
    country_code: str = Field(
        min_length=2,
        max_length=2,
    )
    country_name: str
    locality_name: str
    region_name: Optional[str]
    region_abbreviated_name: Optional[str]
    postal_code: Optional[str]
