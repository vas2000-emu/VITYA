"""
JSON payload validation and sanitization for supplier discovery tools.

Handles:
1. JSON formatting (double quotes enforced at parsing level)
2. Format conversion (General & Portfolio - arrays)
3. Default values (pageSize: 10 when empty)
4. Type validation (numeric as numbers, not strings)
5. Range capping (SSI 0-10, SER 1-9, etc.)
"""
import logging
import json
import ast

logger = logging.getLogger(__name__)

# Parameter type definitions
BOOLEAN_PARAMS = {
    "isManufacturingLocation", "isPubliclyTradedCompany", "isStandalone",
    "isOutOfBusiness", "isSmallBusiness", "isMinorityOwned", "isVeteranOwned",
    "isWomanOwned", "isLGBTQOwned", "isCertifiedSmallBusiness",
    "isAlaskanNativeCorporation", "isMinorityServingInstitution",
    "isDisadvantagedBusinessEnterprise", "isDisabledOwned",
    "hasSignificantEvents", "hasDisastrousEvents", "hasFireOccurred",
    "hasActiveExclusions", "hasInactiveExclusions", "hasEPAViolations",
    "hasOSHAViolations", "hasGCLCitations", "hasCAEnvironmentalViolations",
    "hasLegalEvents", "hasOpenLegalEvents", "hasSuits", "hasOpenSuits",
    "hasLiens", "hasOpenLiens", "hasBankruptcy", "hasOpenBankruptcy",
    "hasJudgments", "hasOpenJudgments", "hasFinancialEmbarrassment",
    "hasOpenFinancialEmbarrassment", "hasCriminalProceedings",
    "hasOpenCriminalProceedings", "hasClaims", "hasOpenClaims",
    "hasDebarments", "hasInsolvency", "hasLiquidation", "hasESGRankingScore"
}

INTEGER_PARAMS = {
    "ssiClassLowScore", "ssiClassHighScore", "serClassLowScore", "serClassHighScore",
    "failureScoreLowPercentile", "failureScoreHighPercentile",
    "delinquencyScoreLowPercentile", "delinquencyScoreHighPercentile",
    "consolidatedEmployeesLowCount", "consolidatedEmployeesHighCount",
    "individualEmployeesLowCount", "individualEmployeesHighCount",
    "startYearLowRange", "startYearHighRange", "familytreeRolesPlayed",
    "paydexLowRangeScore", "paydexHighRangeScore",
    "esgOverallRankingLowRangeScore", "esgOverallRankingHighRangeScore",
    "viabilityLowRangeScore", "viabilityHighRangeScore",
    "overallBusinessRiskAssessmentCodes", "businessEntityType",
    "ownershipPrimaryEthnicityType", "organizationSizeCategory",
    "socioEconomicClassifications", "pageNumber", "pageSize"
}

FLOAT_PARAMS = {
    "salesLowRangeAmount", "salesHighRangeAmount",
    "radiusLat", "radiusLon", "radiusDistance"
}

# Range limits for parameters
RANGE_LIMITS = {
    # SSI score: 1-9
    "ssiClassLowScore": (1, 9),
    "ssiClassHighScore": (1, 9),
    # SER score: 1-9
    "serClassLowScore": (1, 9),
    "serClassHighScore": (1, 9),
    # Paydex: 0-100
    "paydexLowRangeScore": (0, 100),
    "paydexHighRangeScore": (0, 100),
    # ESG ranking: 1-5
    "esgOverallRankingLowRangeScore": (1, 5),
    "esgOverallRankingHighRangeScore": (1, 5),
    # Viability: 1-9
    "viabilityLowRangeScore": (1, 9),
    "viabilityHighRangeScore": (1, 9),
    # Standard rating risk segment: 1-4. D&B API takes integer, data services API needs string
    # "standardRatingLowRangeRiskSegment": (1, 4),
    # "standardRatingHighRangeRiskSegment": (1, 4),
    # Percentiles: 0-100
    "failureScoreLowPercentile": (0, 100),
    "failureScoreHighPercentile": (0, 100),
    "delinquencyScoreLowPercentile": (0, 100),
    "delinquencyScoreHighPercentile": (0, 100),
    # Page size: 1-50
    "pageSize": (1, 50),
}


def parse_payload(payload) -> dict:
    """
    Parse payload from string or dict, handling single quotes gracefully.
    
    Args:
        payload: String (JSON/Python dict) or dict
        
    Returns:
        Parsed dictionary
    """
    if isinstance(payload, dict):
        return payload

    if isinstance(payload, str):
        payload = payload.strip()

        try:
            return json.loads(payload)
        except json.JSONDecodeError:
            pass  # move on to fallback

        try:
            if payload.startswith("{") and "'" in payload and '"' not in payload:
                fixed_payload = payload.replace("'", '"')
                parsed = json.loads(fixed_payload)
                logger.warning("Payload used single quotes - auto-converted to double quotes for JSON parsing")
                return parsed
        except json.JSONDecodeError:
            pass  # fallback again

        try:
            parsed = ast.literal_eval(payload)
            logger.warning("Payload parsed via ast.literal_eval (non-JSON format)")
            return parsed
        except (ValueError, SyntaxError) as e:
            logger.error(f"Failed to parse payload: {e}")
            raise ValueError(f"Invalid payload format: {e}")

    raise ValueError(f"Unsupported payload type: {type(payload)}")


def apply_range_limit(key: str, value):
    """
    Apply range limits to a value based on parameter constraints.
    
    Args:
        key: Parameter name
        value: Value to validate
        
    Returns:
        Value capped to valid range
    """
    if key not in RANGE_LIMITS:
        return value
    
    min_val, max_val = RANGE_LIMITS[key]
    
    # Convert to numeric type for comparison
    try:
        if key in INTEGER_PARAMS:
            numeric_val = int(value)
        elif key in FLOAT_PARAMS:
            numeric_val = float(value)
        else:
            numeric_val = float(value)  # Try float for string params
        
        if numeric_val < min_val:
            logger.warning(f"{key}={numeric_val} is below minimum {min_val}, capping to {min_val}")
            return int(min_val) if key in INTEGER_PARAMS else min_val
        elif numeric_val > max_val:
            logger.warning(f"{key}={numeric_val} exceeds maximum {max_val}, capping to {max_val}")
            return int(max_val) if key in INTEGER_PARAMS else max_val
        return int(numeric_val) if key in INTEGER_PARAMS else numeric_val
    except (ValueError, TypeError):
        # Can't convert to number, return as-is
        return value


def convert_to_type(key: str, value):
    """
    Convert value to appropriate type based on parameter.
    
    Args:
        key: Parameter name
        value: Value to convert
        
    Returns:
        Value converted to correct type
    """
    if key in BOOLEAN_PARAMS:
        if isinstance(value, str):
            # Handle both "true"/"false" and "True"/"False" strings
            lower_val = value.lower()
            if lower_val in ("true", "1", "yes"):
                return True
            elif lower_val in ("false", "0", "no"):
                return False
            else:
                # If not a recognized string, convert to bool
                return bool(value)
        return bool(value)
    
    elif key in INTEGER_PARAMS:
        try:
            return int(value)
        except (ValueError, TypeError):
            logger.warning(f"Could not convert {key}={value} to int")
            return value
    
    elif key in FLOAT_PARAMS:
        try:
            return float(value)
        except (ValueError, TypeError):
            logger.warning(f"Could not convert {key}={value} to float")
            return value
    
    else:
        # String parameters
        return str(value) if value is not None else value


def sanitize_general_payload(payload) -> dict:
    """
    Sanitize payload for general dnb_supplier_discovery tool.
    
    Format: Values as strings/numbers (not arrays), booleans as "true"/"false" strings
    
    Args:
        payload: Raw payload from agent (can be dict or string)
        
    Returns:
        Sanitized payload with proper types and defaults
    """
    # Parse payload first (handles both dict and string inputs)
    payload = parse_payload(payload)
    
    sanitized = {}
    
    for key, value in payload.items():
        # Skip empty values
        if value is None or value == "" or value == []:
            continue
        
        # Extract from array if provided
        if isinstance(value, list):
            if len(value) == 0:
                continue
            value = value[0]
        
        # Convert to proper type
        typed_value = convert_to_type(key, value)
        
        # Apply range limits
        capped_value = apply_range_limit(key, typed_value)
        
        # For general API, booleans must be strings "true"/"false"
        if key in BOOLEAN_PARAMS:
            sanitized[key] = "true" if capped_value else "false"
        else:
            sanitized[key] = capped_value
    
    # Apply defaults
    if "pageSize" not in sanitized or sanitized.get("pageSize") == "":
        sanitized["pageSize"] = 10
    if "pageNumber" not in sanitized:
        sanitized["pageNumber"] = 1
    
    return sanitized


def sanitize_portfolio_payload(payload) -> dict:
    """
    Sanitize payload for portfolio tools (IN & OUT)
    
    Format: Values in arrays, booleans as true/false (not strings)
    
    Args:
        payload: Raw payload from agent (can be dict or string)
        
    Returns:
        Sanitized payload with proper array format and types
    """
    # Parse payload first (handles both dict and string inputs)
    payload = parse_payload(payload)
    
    sanitized = {}
    
    for key, value in payload.items():
        # Skip empty values
        if value is None or value == "" or value == []:
            continue
        
        # pageNumber and pageSize are integers, NOT arrays
        if key in ("pageNumber", "pageSize"):
            # Extract from array if needed
            if isinstance(value, list):
                value = value[0] if len(value) > 0 else None
            
            if value is None or value == "":
                # Apply defaults
                if key == "pageSize":
                    sanitized[key] = 10
                elif key == "pageNumber":
                    sanitized[key] = 1
                continue
            
            # Convert to int
            typed_value = convert_to_type(key, value)
            capped_value = apply_range_limit(key, typed_value)
            sanitized[key] = capped_value
            continue
        
        # All other parameters should be arrays
        values = value if isinstance(value, list) else [value]
        
        # Process each value in the array
        sanitized_array = []
        for v in values:
            if v is None or v == "":
                continue
            
            typed_value = convert_to_type(key, v)
            capped_value = apply_range_limit(key, typed_value)
            sanitized_array.append(capped_value)
        
        if sanitized_array:
            sanitized[key] = sanitized_array
    
    # Apply defaults
    if "pageSize" not in sanitized:
        sanitized["pageSize"] = 10
    if "pageNumber" not in sanitized:
        sanitized["pageNumber"] = 1
    
    return sanitized


def validate_required_fields(payload: dict) -> bool:
    """
    Validate that payload contains at least one required field.
    Required fields: countryISOAlpha2Code, continentalRegion, usSicV4, usSicV8, unspsc, naics
    
    Args:
        payload: Sanitized payload
        
    Returns:
        True if valid, raises ValueError if not
    """
    required_fields = {
        "countryISOAlpha2Code", "continentalRegion", "usSicV4", 
        "usSicV8", "unspsc", "naics"
    }
    
    has_required = any(key in payload for key in required_fields)
    
    if not has_required:
        raise ValueError(
            "Payload must contain at least one of: "
            "countryISOAlpha2Code, continentalRegion, usSicV4, usSicV8, unspsc, naics"
        )
    
    return True
