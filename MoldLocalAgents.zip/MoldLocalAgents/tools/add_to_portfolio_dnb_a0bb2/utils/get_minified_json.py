import logging
import collections

logger = logging.getLogger(__name__)

def traverse_build(data, path):
    """
    Extract a minified JSON structure containing only the specified path.
    
    This function traverses nested dictionaries and lists to extract only the data
    at the specified dot-separated path, preserving the full nested structure.
    
    Args:
        data: Source JSON data (dict or list)
        path: Dot-separated path (e.g., "organization.dnbAssessment.failureScore.nationalPercentile")
    
    Returns:
        dict or list: Minified JSON preserving the nested structure up to the specified path.
                     Returns empty dict {} if path doesn't exist.
    
    Examples:
        >>> data = {"org": {"dept": {"name": "Sales"}}}
        >>> traverse_build(data, "org.dept.name")
        {"org": {"dept": {"name": "Sales"}}}
        
        >>> data = {"items": [{"id": 1, "name": "A"}, {"id": 2, "name": "B"}]}
        >>> traverse_build(data, "items.name")
        {"items": [{"name": "A"}, {"name": "B"}]}
    """
    if not path or not isinstance(path, str):
        return {}
    
    fields = path.split(".")
    result = _build_nested_structure(data, fields, 0)
    
    return result if result is not None else {}


def _build_nested_structure(data, fields, index):
    """
    Recursively build the nested structure for the given path.
    
    Args:
        data: Current level of data being processed
        fields: List of field names in the path
        index: Current position in the fields list
    
    Returns:
        Nested structure containing only the specified path, or None if path doesn't exist at all
    """
    # Base case: reached the end of the path
    if index >= len(fields):
        return data
    
    current_field = fields[index]
    
    # Handle list data - apply path extraction to each item
    if isinstance(data, list):
        result = []
        for item in data:
            extracted = _build_nested_structure(item, fields, index)
            # Only include items where the path exists
            if extracted is not None:
                result.append(extracted)
        return result if result else None
    
    # Handle dict data
    elif isinstance(data, dict):
        # Check if current field exists in the dictionary
        if current_field not in data:
            # Current field doesn't exist
            # We want to preserve structure up to this level, showing the field as empty
            return {current_field: {}}
        
        value = data[current_field]
        
        # Last field in path - return the complete value wrapped in dict
        if index == len(fields) - 1:
            return {current_field: value}
        
        # Not the last field - need to recurse deeper
        # Check if we can traverse deeper (value must be dict or list)
        if not isinstance(value, (dict, list)):
            # Can't traverse into primitive types - preserve what we have
            return {current_field: value}
        
        # Value is a dict or list, try to recurse deeper
        # Special handling for dict: check if next field exists
        if isinstance(value, dict):
            next_field = fields[index + 1]
            if next_field not in value:
                # Next field doesn't exist in this dict
                # Return empty dict to show structure exists but field doesn't
                return {current_field: {}}
            # Next field exists, recurse into it
            nested_result = _build_nested_structure(value, fields, index + 1)
            # Wrap the result
            return {current_field: nested_result}
        
        # For lists, recurse into each item
        if isinstance(value, list):
            nested_result = _build_nested_structure(value, fields, index + 1)
            if nested_result is None or (isinstance(nested_result, list) and len(nested_result) == 0):
                # No items in the list matched the path - preserve the list
                return {current_field: value}
            return {current_field: nested_result}
        
        # Shouldn't reach here, but be defensive
        return None
    
    # Handle primitive types (shouldn't happen in valid paths, but be defensive)
    else:
        return None
        
def update(d, u):
    """recursive helper method to update dictionary d with dictionary u
    
    Handles nested dictionaries and lists intelligently:
    - If both are dicts: recursively merge
    - If both are lists of same length: merge corresponding items
    - If update is dict but original is list: merge into first list item
    - If update is list but original is dict: assign the list
    - Otherwise: assign the update value

    Args:
        d (dict): dictionary to be updated 
        u (dict): dictionary to update with

    Returns:
        dict: updated dictionary d
    """
    for k, v in u.items():
        d_val = d.get(k)
        
        # Case 1: Both are dictionaries - recursively merge
        if isinstance(v, collections.abc.Mapping) and isinstance(d_val, collections.abc.Mapping):
            d[k] = update(d_val, v)
        # Case 2: Both are lists of same length - merge corresponding items
        elif isinstance(v, list) and isinstance(d_val, list) and len(d_val) == len(v):
            for i, item in enumerate(v):
                # If both items are dictionaries, recursively merge
                if isinstance(item, collections.abc.Mapping) and isinstance(d_val[i], collections.abc.Mapping):
                    d_val[i] = update(d_val[i], item)
                # Otherwise, replace with the update value
                else:
                    d_val[i] = item
        # Case 3: Update is dict but original is list - merge into first list item
        elif isinstance(v, collections.abc.Mapping) and isinstance(d_val, list):
            if len(d_val) > 0:
                # Merge into first item if it's a dict, otherwise replace
                if isinstance(d_val[0], collections.abc.Mapping):
                    d_val[0] = update(d_val[0], v)
                else:
                    d_val[0] = v
        # Case 4: Update is list but original is list of different length
        elif isinstance(v, list) and isinstance(d_val, list) and len(d_val) != len(v):
            # # Alternative behavior - Extend the list
            # d_val.extend(v)

            # Merge corresponding items up to the shorter length, preserve all original items
            min_len = min(len(d_val), len(v))
            for i in range(min_len):
                if isinstance(v[i], collections.abc.Mapping) and isinstance(d_val[i], collections.abc.Mapping):
                    d_val[i] = update(d_val[i], v[i])
                else:
                    d_val[i] = v[i]
            # Keep the rest of the original list (if it was longer)
            # Don't add extra items from v (if v was longer) to avoid data loss
        # Case 5: Default - assign the value
        else:
            d[k] = v
    return d

def get_json(result_blocks, key, data, support_metadata):
    """
    this method takes the result_blocks from vector search and generate "minified" json from dnb data blocks

    Args:
        result_blocks (dictionary): vector search results with best matching blocks and fields.
        key (str): a key of result_blocks
        support_metadata: support metadata to add to the minified json

    Returns:
        dictionary: minified json to be used for RAG
    """
    block_dicts = {}
    try:
        meta_data_block = support_metadata.get(key)
        for path in result_blocks.get(key):
            try:
                meta_data_path = meta_data_block.get(path) if meta_data_block else None
                data_dict = traverse_build(data, path)
                if meta_data_path:
                    # data_dict[path + " description"] = meta_data_path
                    data_dict = update(data_dict, meta_data_path)
                block_dicts = update(block_dicts, data_dict)
            except Exception as e:
                logger.error(repr(e))
                # print(repr(e))
                continue
        
    except Exception as e:
        logger.error(repr(e))
        # print(repr(e))

    return block_dicts