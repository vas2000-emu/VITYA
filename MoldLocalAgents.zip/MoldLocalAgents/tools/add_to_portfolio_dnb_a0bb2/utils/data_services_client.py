import base64
import aiohttp
import ssl
import certifi
import requests


# import json
# from typing import Any, Optional


class DataServicesClient:
    """A remote client for Data Services."""

    async def authenticate(self):
        # Combine client_id and client_secret with a colon and encode to bytes
        credentials_string = f"{self._client_id}:{self._client_secret}"
        credentials_bytes = credentials_string.encode("utf-8")

        # Base64 encode the credentials
        encoded_credentials_bytes = base64.b64encode(credentials_bytes)
        encoded_credentials_string = encoded_credentials_bytes.decode("utf-8")

        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"Basic {encoded_credentials_string}",
        }

        data = {"grant_type": "client_credentials", "scope": "read,write"}

        # Use aiohttp for async HTTP request
        ssl_context = ssl.create_default_context(cafile=certifi.where())
        connector = aiohttp.TCPConnector(ssl=ssl_context)

        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.post(url=self._token_url, data=data, headers=headers) as response:
                if response.status == 200:
                    auth_data = await response.json()
                    self.bearer_token = auth_data.get("access_token")
                    assert self.bearer_token, "Failed to fetch Bearer token for Data Services client"
                else:
                    raise Exception(f"Authentication failed with status {response.status}")

    def authenticate_sync(self):
        """Synchronous version for backward compatibility"""
        # Combine client_id and client_secret with a colon and encode to bytes
        credentials_string = f"{self._client_id}:{self._client_secret}"
        credentials_bytes = credentials_string.encode("utf-8")

        # Base64 encode the credentials
        encoded_credentials_bytes = base64.b64encode(credentials_bytes)
        encoded_credentials_string = encoded_credentials_bytes.decode("utf-8")

        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"Basic {encoded_credentials_string}",
        }

        data = {"grant_type": "client_credentials", "scope": "read,write"}
        
        try:
            # Use certifi for SSL verification (matching async version)
            authentication_response = requests.post(
                url=self._token_url, 
                data=data, 
                headers=headers,
                timeout=30,  # Add timeout to prevent hanging
            )
            
            # Check response status before parsing JSON
            if authentication_response.status_code == 200:
                try:
                    auth_data = authentication_response.json()
                    self.bearer_token = auth_data.get("access_token")
                    if not self.bearer_token:
                        raise Exception("Failed to fetch Bearer token for Data Services client: access_token not found in response")
                except ValueError as e:
                    raise Exception(f"Failed to parse authentication response as JSON: {e}")
            else:
                # Include response text in error for debugging
                error_text = authentication_response.text[:500]  # Limit error text length
                raise Exception(
                    f"Authentication failed with status {authentication_response.status_code}: {error_text}"
                )
        except requests.exceptions.Timeout:
            raise Exception(f"Authentication request timed out after 30 seconds for URL: {self._token_url}")
        except requests.exceptions.ConnectionError as e:
            raise Exception(f"Failed to connect to authentication server at {self._token_url}: {e}")
        except requests.exceptions.RequestException as e:
            raise Exception(f"Authentication request failed: {e}")

    def __init__(self, base_url: str, token_url: str, client_id: str, client_secret: str):
        """
        :param base_url: The base URL for the Data Services API.
        :param token_url: The URL for authentication tokens for the Data Services API.
        :param client_id: Client ID for Data Services API.
        :param client_secret: Client secret for Data Services API.
        """
        self._base_url = base_url
        self._token_url = token_url
        self._client_id = client_id
        self._client_secret = client_secret
        # Note: authenticate() is now async, call authenticate_sync() for synchronous initialization
        # or use await client.authenticate() in async contexts
        self.bearer_token = None

    def is_authenticated(self) -> bool:
        """Check if the client has a valid bearer token"""
        return self.bearer_token is not None